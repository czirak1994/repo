

'''----------------------------------------------------------------------------------
                                WebSocket metodusok'''
# Define WebSocket event handlers
@socketio.on('connect')
def handle_connect():
    logger.info("Client connected")
    emit('response', {'message': 'Connected to WebSocket'})

@socketio.on('disconnect')
def handle_disconnect():
    logger.info("Client disconnected")

# In-memory storage for orders
orders_data = []


@socketio.on('send_order_updates')
def handle_order_updates(data):
    global orders_data
    try:
        raw_orders = data.get('orders', [])

        # Ellenőrizzük, hogy a raw_orders lista-e
        if not isinstance(raw_orders, list):
            logger.error("A raw_orders mező nem egy lista.")
            raw_orders = [raw_orders]  # Ha nem, csomagoljuk be egy listába

        logger.info(f"Kapott rendelések a WebSocket-en keresztül: {raw_orders}")

        # Frissítsük az orders_data változót
        orders_data.extend(raw_orders)
        logger.debug(f"Frissített orders_data: {orders_data}")

        emit('response', {'message': 'Order updates received'})
    except Exception as e:
        logger.error(f"Hiba a rendelések feldolgozása során: {e}")
        emit('response', {'message': f'Hiba történt: {str(e)}'})

