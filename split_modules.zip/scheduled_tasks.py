

'''----------------------------------------------------------------------------------
MaterialOrderProcessor osztály példányosítása az orders metódus számára, ez nem megfelelő mód'''

# SAP osztály példányosítása
processor = MaterialOrderProcessor()


# Globális változók
last_sent_data = None
stop_thread = False

