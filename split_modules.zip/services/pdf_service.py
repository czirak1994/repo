

# Indítsuk el az időzített feladatot külön szálon
scheduler_thread = threading.Thread(target=scheduled_task)
scheduler_thread.daemon = True
scheduler_thread.start()


if __name__ == "__main__":
    try:
        socketio.run(app, host='0.0.0.0', port=5000, debug=True)
    except KeyboardInterrupt:
        stop_thread = True
        scheduler_thread.join()
        
        