

import os

def print_pdf(file_path, printer_name=None):
    """
    Print a PDF file using the default system printer or a specified printer.

    :param file_path: Path to the PDF file to print.
    :param printer_name: Optional name of the printer. Ignored in os.startfile.
    """
    try:
        # Ellenőrizzük, hogy a fájl létezik-e
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File {file_path} does not exist.")
        
        # Az alapértelmezett nyomtatóra küldés
        os.startfile(file_path, "print")
        logging.info(f"Printing {file_path} using the default printer.")
    except Exception as e:
        logging.error(f"Failed to print PDF: {e}")
        raise RuntimeError(f"Failed to print PDF: {e}")
