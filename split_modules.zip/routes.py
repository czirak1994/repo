

'''----------------------------------------------------------------------------------
                Json adatok előkészítése és küldés websocket-en'''
class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)  # Convert Decimal to float
        if isinstance(obj, datetime):
            return obj.isoformat()  # Convert datetime to ISO 8601 string
        return super().default(obj)



async def send_data_to_websocket(data):
    websocket_url = "wss://mor-taskapp.devpods.benteler.net/ws/orders/"
    try:
        # Wrap data in an 'orders' key and ensure it is serialized properly
        payload = {"orders": data}  # Correct the wrapping step
        serialized_data = json.dumps(payload, cls=CustomJSONEncoder)

        logging.info("Connecting to WebSocket server...")
        async with websockets.connect(websocket_url) as websocket:
            logging.info("WebSocket connection established.")
            
            # Send data
            logging.info("Sending data to WebSocket server...")
            await websocket.send(serialized_data)
            logging.debug(f"Data sent: {serialized_data[:500]}... (truncated for log)")
            
            # Await response
            response = await websocket.recv()
            logging.info(f"WebSocket response received: {response}")
            return response
    except Exception as e:
        logging.error(f"Error during WebSocket communication: {e}")
'''----------------------------------------------------------------------------------
                        Időzített metódus hívás'''
def scheduled_task():
    """Időzített adatküldő feladat."""
    global last_sent_data, stop_thread
    while not stop_thread:
        current_time = datetime.now()
        if current_time.minute in [15, 45]:  # 15 és 45 perckor küldés
            logging.debug("Időzített WebSocket küldés fut...")
            if last_sent_data:
                asyncio.run(send_data_to_websocket(last_sent_data))
            else:
                logging.debug("Nincsenek elérhető adatok a küldéshez.")
            time.sleep(60)  # Várjunk 60 másodpercet, hogy ne fusson többször ugyanabban a percben
        time.sleep(1)  # Ellenőrizze az időt másodpercenként



'''----------------------------------------------------------------------------------
                                Weboldal metodusok'''
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        try:
            # SAP kapcsolat tesztelése
            conn = Connection(
                user=username,
                passwd=password,
                ashost="csgppadpeu.benteler.net",
                sysnr="78",
                client="100"
            )
            # Ha a kapcsolat sikeres, mentjük a session-be
            session["username"] = username
            session["password"] = password
            return redirect(url_for("orders"))
        except Exception as e:
            return render_template("login.html", error=f"SAP kapcsolat hiba: {e}")
    return render_template("login.html")



@app.route("/orders", methods=["GET"])
def orders():
    global last_sent_data, result_df_global
    if "username" not in session or "password" not in session:
        return redirect(url_for("login"))

    try:
        conn = Connection(
            user=session["username"],
            passwd=session["password"],
            ashost="csgppadpeu.benteler.net",
            sysnr="78",
            client="100"
        )

        processor = MaterialOrderProcessor()
        result_df = processor.process_orders(conn)

        # Alkalmazd az oszlopokra a szükséges átalakításokat
        result_df['MATNR'] = result_df['MATNR'].apply(lambda x: x.lstrip('0'))
        result_df['MENGE'] = result_df['MENGE'].apply(lambda x: int(float(x)) if pd.notnull(x) else 0)
        result_df['STATUS'] = result_df['STATUS'].apply(lambda x: (x.strip() if isinstance(x, str) else "unknown"))
        result_df['LAGERPLATZ'] = result_df['LAGERPLATZ'].apply(lambda x: (x.strip() if isinstance(x, str) else ""))
        result_df['FIFOKEY'] = result_df['FIFOKEY'].apply(lambda x: (x.strip() if isinstance(x, str) else ""))

        # Initialize data immediately after processing
        last_sent_data = result_df.to_dict(orient="records")
        result_df_global = result_df

        return render_template("orders.html", orders=last_sent_data)

    except Exception as e:
        logging.error(f"Error in /orders: {e}")
        return render_template("orders.html", error=f"Hiba az adatok lekérése során: {e}")




@app.route("/send", methods=["POST"])
def send():
    global last_sent_data
    if not last_sent_data:
        logging.warning("No data available to send.")
        return jsonify({"message": "Nincsenek elérhető adatok a küldéshez."}), 400

    try:
        # Log raw data
        logging.debug(f"Raw orders: {json.dumps(last_sent_data[:5], cls=CustomJSONEncoder)} (truncated)")

        # Közvetlenül küldjük a tisztított adatokat
        asyncio.run(send_data_to_websocket(last_sent_data))
        return jsonify({"message": "Adatok sikeresen elküldve WebSocket-en!"})
    except Exception as e:
        logging.error(f"Hiba WebSocket küldése során: {e}")
        return jsonify({"message": "Hiba történt az adatok küldése során."}), 500

@app.route("/api/orders", methods=["GET"])
def get_orders():
    global last_sent_data
    try:
        logging.debug(f"Current last_sent_data: {last_sent_data}")
        
        # Force empty list to be actual list if None
        if last_sent_data is None:
            last_sent_data = []
            
        # Return data even if empty
        return jsonify(last_sent_data), 200
        
    except Exception as e:
        logging.error(f"Hiba az /api/orders feldolgozásában: {e}")
        return jsonify([]), 200  # Return empty array instead of error







@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/printers", methods=['GET'])
def get_printers():
    try:
        printers = list_printers()
        logging.debug(f"Available printers: {printers}")
        return jsonify(printers)
    except Exception as e:
        logging.error(f"Error listing printers: {e}")
        return jsonify([])


@app.route('/select_printer', methods=['POST'])
def select_printer_route():
    selected_printer = request.json.get('printer')
    # Store the selected printer in session or a global variable
    # For demonstration, just return the selected printer
    return jsonify({"selected_printer": selected_printer})

def create_nosupply_df(result_df):
    nosuply_df = result_df[result_df['OBJKEY'].isnull() | (result_df['OBJKEY'] == '')]
    return nosuply_df

def list_printers():
    printers = [printer[2] for printer in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
    return printers

@app.route('/generate_and_print_pdf', methods=['POST'])
def generate_and_print_pdf():
    global result_df_global
    try:
        selected_printer = request.json.get('printer')
        if not selected_printer:
            return jsonify({"message": "No printer selected."}), 400

        if result_df_global is None:
            return jsonify({"message": "No data available to generate PDF."}), 400

        # Create nosuply_df from result_df_global
        nosuply_df = result_df_global[result_df_global['OBJKEY'].isnull() | (result_df_global['OBJKEY'] == '')]

        qr_image_path = "qr_code.png"
        output_filename = "output.pdf"

        # Create an instance of PDFGenerator
        pdf_generator = PDFGenerator()

        # Generate the PDF
        pdf_generator.create_pdf_with_two_part_tables_sorted(result_df_global, nosuply_df, qr_image_path, output_filename)

        # Nyomtatás rendszerparanccsal
        pdf_path = os.path.abspath(output_filename)
        print_command = f'print /d:"{selected_printer}" "{pdf_path}"'
        os.system(print_command)

        return jsonify({"message": f"PDF successfully sent to {selected_printer}."})

    except Exception as e:
        logging.error(f"Error in generate_and_print_pdf: {e}")
        return jsonify({"message": f"Error: {str(e)}"}), 500

