from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_socketio import SocketIO, emit
from pyrfc import Connection
import win32print
import win32api
from pdf_generator import PDFGenerator
import pandas as pd
from datetime import datetime
from decimal import Decimal
import threading
import time
import asyncio
import websockets
import json
from sap_functions import MaterialOrderProcessor
import logging

'''----------------------------------------------------------------------------------
                                Logging konfiguráció'''
# Logging konfiguráció
logging.basicConfig(
    level=logging.DEBUG,  # Szint: DEBUG, INFO, WARNING, ERROR, CRITICAL
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("app.log", encoding="utf-8"),  # Fájlba naplózás
        logging.StreamHandler()  # Konzolra naplózás
    ]
)

# Példa logger
logger = logging.getLogger(__name__)
