

'''----------------------------------------------------------------------------------
Flask app és SocketIO konfiguráció, metódus kell a secretkey létrehozásához'''

app = Flask(__name__)
app.secret_key = "your_secret_key"
socketio = SocketIO(app)
