import logging

logging.basicConfig(level=logging.DEBUG)

class SAPWorker:
    def __init__(self, connection):
        self.connection = connection
        
    def call_function_module(self, module_name, parameters):
        try:
            result = self.connection.call(module_name, **parameters)
            return result
        except Exception as e:
            logging.error(f"Error calling SAP function: {e}")
            return None    