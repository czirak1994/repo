import logging
import json
from pyrfc import Connection, ABAPApplicationError, ABAPRuntimeError, CommunicationError, LogonError

logging.basicConfig(level=logging.DEBUG)

class ConnectionHandler:
    def __init__(self):
        with open('config.json', 'r') as f:
            self.config = json.load(f)['sap_server']
        self.connection = None
        
    def connect(self, username, password):
        try:
            self.config['user'] = username
            self.config['password'] = password
            self.connection = Connection(**self.config)
            return self.connection
        except (ABAPApplicationError, ABAPRuntimeError, CommunicationError, LogonError) as e:
            logging.error(f"Error connecting to SAP: {e}")
            return None
    
    def close(self):
        if self.connection:
            self.connection.close()            