from django.urls import path
from prodplan.views.login_view import login_view


urlpatterns = [
    path('login/', login_view, name='login'),  # Bejelentkezés
    # Ide kerülhetnek további nézetek, például:
    # path('dashboard/', dashboard_view, name='dashboard'),
]
