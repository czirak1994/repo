from django.shortcuts import render, redirect
from django.contrib import messages
from prodplan.utils.connection_handler import ConnectionHandler

connection_handler = ConnectionHandler()

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        connection = connection_handler.connect(username, password)
        
        if connection:
            request.session['user'] = username
            messages.success(request, 'Login successful!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
            
    return render(request, 'login.html')        