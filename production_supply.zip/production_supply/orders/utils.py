from datetime import datetime, timedelta
from django.utils.timezone import now
from pyrfc import Connection, CommunicationError, ABAPApplicationError, ABAPRuntimeError
from django.conf import settings
import logging

def get_sap_connection(request):
    try:
        sap_user = request.session.get('sap_user')
        sap_password = request.session.get('sap_password')
        last_connection_time = request.session.get('last_connection_time')

        if not sap_user or not sap_password:
            raise ValueError("SAP bejelentkezési adatok hiányoznak.")

        # Ellenőrizzük, hogy a kapcsolat friss-e (30 perc)
        if last_connection_time:
            last_connection_time = datetime.fromisoformat(last_connection_time)
            if now() - last_connection_time < timedelta(minutes=30):
                logging.info("Új kapcsolat létrehozása nem szükséges.")
                return Connection(
                    user=sap_user,
                    passwd=sap_password,
                    ashost=settings.SAP_HOST,
                    sysnr=settings.SAP_SYSNR,
                    client=settings.SAP_CLIENT
                )

        # Új kapcsolat létrehozása
        conn = Connection(
            user=sap_user,
            passwd=sap_password,
            ashost=settings.SAP_HOST,
            sysnr=settings.SAP_SYSNR,
            client=settings.SAP_CLIENT
        )
        request.session['last_connection_time'] = now().isoformat()  # Frissítjük az időbélyeget
        logging.info("Új SAP kapcsolat létrehozva.")
        return conn

    except (CommunicationError, ABAPApplicationError, ABAPRuntimeError) as sap_error:
        logging.error(f"Hiba történt az SAP kapcsolat során: {sap_error}")
        raise ValueError("Nem sikerült az SAP kapcsolódás.")

    except Exception as e:
        logging.error(f"Ismeretlen hiba a kapcsolat létrehozása során: {e}")
        raise ValueError("Hiba történt a kapcsolat létrehozása során.")
