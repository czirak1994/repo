from django.urls import path
from . import views

app_name = 'orders'

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('orders/', views.orders_view, name='orders_view'),  # Az orders.html nézet URL-je
]
