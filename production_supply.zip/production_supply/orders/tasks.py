import json
import websockets
import pandas as pd
from datetime import datetime
from .sap_functions import SapWorker
from .utils import get_sap_connection
import logging

async def send_to_local_ws(data):
    """Adatok küldése a helyi WebSocket szerverre."""
    ws_url = 'ws://127.0.0.1:8000/ws/orders/'  # Helyi WebSocket szerver URL-je
    try:
        async with websockets.connect(ws_url) as websocket:
            await websocket.send(json.dumps(data))
            response = await websocket.recv()
            logging.info(f"Helyi WebSocket válasz: {response}")
    except Exception as e:
        logging.error(f"Hiba történt a WebSocket kapcsolat során: {e}")

async def call_sap_function():
    """Az SAP funkciómodulok hívása és adatok feldolgozása."""
    logging.info(f"Funkciómodul hívás indult: {datetime.now()}")
    try:
        # SAP kapcsolat létrehozása
        conn = get_sap_connection()

        # SAP adatok feldolgozása
        sap_worker = SapWorker()
        material_orders = sap_worker.get_material_orders(conn)
        df_status_combined = pd.concat([
            sap_worker.fetch_data(conn, '01'),
            sap_worker.fetch_data(conn, '00'),
            sap_worker.fetch_data(conn, '40')
        ], ignore_index=True)
        processed_data = sap_worker.assign_objkey_to_orders(material_orders, df_status_combined)
        processed_data = sap_worker.update_matbez_final(conn, processed_data)

        # Adatok küldése a helyi WebSocket szerverre
        data = processed_data.to_dict(orient='records')
        await send_to_local_ws(data)

        logging.info("SAP funkciómodulok sikeresen futottak.")
    except Exception as e:
        logging.error(f"Hiba történt az SAP funkciómodulok hívása során: {e}")
