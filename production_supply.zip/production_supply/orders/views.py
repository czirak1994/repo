import pandas as pd
import logging
import threading
from django.shortcuts import render, redirect
from django.contrib import messages
from django.utils.timezone import now
from pyrfc import Connection, CommunicationError, ABAPApplicationError, ABAPRuntimeError
from django.conf import settings
from .sap_functions import SapWorker
from .utils import get_sap_connection

def login_view(request):
    if request.method == 'POST':
        sap_user = request.POST.get('username')
        sap_password = request.POST.get('password')

        if not sap_user or not sap_password:
            messages.error(request, "Felhasználónév és jelszó megadása kötelező!")
            return render(request, 'orders/login.html')

        try:
            # Pyrfc kapcsolat tesztelése
            conn = Connection(
                user=sap_user,
                passwd=sap_password,
                ashost=settings.SAP_HOST,
                sysnr=settings.SAP_SYSNR,
                client=settings.SAP_CLIENT
            )
            conn.ping()  # Teszteljük, hogy a kapcsolat él-e

            # Bejelentkezési adatok és időbélyeg tárolása a session-ben
            request.session['sap_user'] = sap_user
            request.session['sap_password'] = sap_password
            request.session['last_connection_time'] = now().isoformat()

            messages.success(request, "Sikeres bejelentkezés!")
            return redirect('orders:orders_view')  # Átirányítás az orders.html-re

        except (CommunicationError, ABAPApplicationError, ABAPRuntimeError) as e:
            messages.error(request, f"Bejelentkezési hiba: {str(e)}")

    return render(request, 'orders/login.html')

def orders_view(request):
    """
    Nézet az SAP adatok feldolgozására és megjelenítésére szálkezeléssel.
    """
    # Eredmények tárolására szolgáló változó
    result_data = {"data": None, "error": None}

    # Adatfeldolgozási függvény (szálban fut)
    def process_data():
        try:
            conn = get_sap_connection(request)  # SAP kapcsolat létrehozása
            sap_worker = SapWorker()

            # SAP adatok lekérése és feldolgozása
            material_orders = sap_worker.get_material_orders(conn)
            df_status_combined = pd.concat([
                sap_worker.fetch_data(conn, '01'),
                sap_worker.fetch_data(conn, '00'),
                sap_worker.fetch_data(conn, '40')
            ], ignore_index=True)
            processed_data = sap_worker.assign_objkey_to_orders(material_orders, df_status_combined)
            processed_data = sap_worker.update_matbez_final(conn, processed_data)

            # Adatok sikeres feldolgozása
            result_data["data"] = processed_data.to_dict(orient="records")
        except Exception as e:
            logging.error(f"Hiba történt az adatok feldolgozása során: {e}")
            result_data["error"] = "Hiba történt az adatok feldolgozása során."

    # Szál indítása
    worker_thread = threading.Thread(target=process_data)
    worker_thread.start()
    worker_thread.join()  # Várjuk meg, amíg a szál befejeződik

    # Hiba esetén hibaüzenet megjelenítése
    if result_data["error"]:
        return render(request, 'orders/orders.html', {'error': result_data["error"]})

    # Eredmények megjelenítése a sablonban
    return render(request, 'orders/orders.html', {'material_orders': result_data["data"]})
