import pandas as pd
import logging

class SapWorker():
    def get_material_orders(self, conn):
        result = conn.call('Z_XTRACT_IS_TABLE',
                           QUERY_TABLE='ZSD_BOS_MATANF',
                           DELIMITER='|',
                           ROWSKIPS=0,
                           NO_DATA='',
                           FIELDS=[{'FIELDNAME': "AUFTRAGNR"},
                                   {'FIELDNAME': "ANLIEF_PUNKT"},
                                   {'FIELDNAME': "MATNR"},
                                   {'FIELDNAME': "ANF_DATE"},
                                   {'FIELDNAME': "ANF_TIME"},
                                   {'FIELDNAME': "PLAN_ANL_DATE"},
                                   {'FIELDNAME': "PLAN_ANL_TIME"}],
                           OPTIONS=[{'TEXT': "WERKS = '0291' and VSTAT = '' and ASTAT = '00' and POSNR = '1'"}])

        field_names = [field['FIELDNAME'] for field in result['FIELDS']]
        rows = [record['FELD'].split('|') for record in result['DATA']]
        material_orders = pd.DataFrame(rows, columns=field_names)
        return material_orders

    def fetch_data(self, conn, status):
        try:
            parameters = {
                'I_STATUS': status,
                'I_WERKS': '0291'
            }
            result = conn.call('ZTRB_DB_EMERGENCY_READ', **parameters)
            e_ztrb_db = result.get('E_ZTRB_DB', [])
            if not e_ztrb_db:
                return pd.DataFrame()
            df = pd.DataFrame(e_ztrb_db)
            columns_to_keep = ['OBJKEY', 'MATNR', 'MATBEZ', 'STATUS', 'LAGERPLATZ', 'MENGE', 'FIFOKEY']
            return df[columns_to_keep] if not df.empty else pd.DataFrame()
        except Exception as e:
            logging.error(f"Error calling SAP function with I_STATUS {status}: {e}")
            return pd.DataFrame()

    def assign_objkey_to_orders(self, material_orders, df_traceability):
        if df_traceability.empty:
            material_orders['OBJKEY'] = "Nincs készlet"
            for col in ['MATBEZ', 'STATUS', 'LAGERPLATZ', 'MENGE', 'FIFOKEY']:
                material_orders[col] = None
            return material_orders

        df_traceability_sorted = df_traceability.sort_values(by=['MATNR', 'FIFOKEY'])
        material_orders['OBJKEY'] = "Nincs készlet"
        for col in ['MATBEZ', 'STATUS', 'LAGERPLATZ', 'MENGE', 'FIFOKEY']:
            material_orders[col] = None

        for index, row in material_orders.iterrows():
            matnr = row['MATNR']
            matching_rows = df_traceability_sorted[df_traceability_sorted['MATNR'] == matnr]

            if not matching_rows.empty:
                selected_row = matching_rows.iloc[0]
                material_orders.at[index, 'OBJKEY'] = selected_row['OBJKEY']
                for col in ['MATBEZ', 'STATUS', 'LAGERPLATZ', 'MENGE', 'FIFOKEY']:
                    material_orders.at[index, col] = selected_row[col]
                df_traceability_sorted = df_traceability_sorted.drop(selected_row.name)

        return material_orders

    def update_matbez_final(self, conn, result_df):
        """
        Frissíti a MATBEZ oszlopot csak azoknál a soroknál, ahol az hiányzik vagy hibás.
        
        Parameters:
        conn (Connection): SAP RFC kapcsolat
        result_df (DataFrame): A végső eredmény DataFrame
        
        Returns:
        DataFrame: A frissített DataFrame
        """
        # Szűrés: csak azok a sorok, ahol MATBEZ üres vagy hibás
        missing_matbez = result_df[
            (result_df['MATBEZ'].isnull()) | 
            (result_df['MATBEZ'] == '') | 
            (result_df['MATBEZ'] == 'Nincs megnevezés') | 
            (result_df['MATBEZ'] == 'Hiba történt')
        ]

        for index, row in missing_matbez.iterrows():
            matnr = row['MATNR']
            matbez = self.get_matbez(conn, matnr)
            result_df.at[index, 'MATBEZ'] = matbez
        return result_df


    def get_matbez(self, conn, matnr):
        """
        Lekérdezi a MATBEZ értéket a Z_PPMES_GET_MATSPR function module segítségével.
        
        Parameters:
        conn (Connection): SAP RFC kapcsolat
        matnr (str): Anyagszám
        
        Returns:
        str: MATBEZ érték vagy alapértelmezett 'Nincs megnevezés'
        """
        try:
            # SAP RFC hívás
            result = conn.call('Z_MMEK_RFC_GET_MARA', IM_MATNR=matnr)
            ex_mara = result.get('EX_MARA', {})
            matbez = ex_mara.get('MAKTX', '').strip()

            # Ellenőrizd, hogy van-e visszatérési érték
            if matbez:
                return matbez
            else:
                logging.warning(f"MATBEZ nem található a következő anyagszámhoz: {matnr}")
                return "Nincs megnevezés"
        except Exception as e:
            logging.error(f"Hiba történt a MATBEZ lekérdezése során (MATNR: {matnr}): {e}")
            return "Hiba történt"