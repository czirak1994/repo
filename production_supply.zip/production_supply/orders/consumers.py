import json
from channels.generic.websocket import AsyncWebsocketConsumer
import websockets

class OrdersConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # Kapcsolat elfogadása
        await self.accept()
        self.external_ws_url = 'wss://mor-taskapp.devpods.benteler.net/ws/orders/'

    async def disconnect(self, close_code):
        # Kapcsolat bontása
        pass

    async def receive(self, text_data):
        # Adatok fogadása
        data = json.loads(text_data)
        
        # Továbbítás a külső szerverre
        try:
            async with websockets.connect(self.external_ws_url) as external_ws:
                await external_ws.send(json.dumps(data))
                response = await external_ws.recv()
                await self.send(text_data=json.dumps({"status": "success", "response": response}))
        except Exception as e:
            await self.send(text_data=json.dumps({"status": "error", "message": str(e)}))
