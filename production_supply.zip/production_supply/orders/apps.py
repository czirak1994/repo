from django.apps import AppConfig
import threading
from .tasks import call_sap_function  # Az ütemező futtatása

class OrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orders'

    def ready(self):
        # Ütemező elindítása külön szálon
        threading.Thread(target=call_sap_function, daemon=True).start()
