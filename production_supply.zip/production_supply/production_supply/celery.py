from __future__ import absolute_import, unicode_literals
import os
from celery import Celery

# Az alapértelmezett Django settings modul betöltése
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'production_supply.settings')

app = Celery('production_supply')

# Konfiguráció betöltése a Django settings fájlból
app.config_from_object('django.conf:settings', namespace='CELERY')

# Feladatok automatikus felfedezése az alkalmazásokban
app.autodiscover_tasks()

@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')
