import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from orders.routing import websocket_urlpatterns
from django.contrib.staticfiles.handlers import ASGIStaticFilesHandler

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'production_supply.settings')

application = ProtocolTypeRouter({
    # Statikus fájlok kezelése fejlesztési módban
    "http": ASGIStaticFilesHandler(get_asgi_application()),
    # WebSocket kérések irányítása
    "websocket": AuthMiddlewareStack(
        URLRouter(
            websocket_urlpatterns
        )
    ),
})
