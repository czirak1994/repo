from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # Admin felület
    path('orders/', include('orders.urls')),  # Az 'orders' app URL-jeinek hozzáadása
]
