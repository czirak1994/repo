// WebSocket kapcsolódás
const websocketUrl = "ws://127.0.0.1:8000/ws/orders/"; // Helyi WebSocket cím
const ws = new WebSocket(websocketUrl);

// Kapcsolat nyitása
ws.onopen = function () {
    console.log("WebSocket kapcsolat létrejött.");
};

// Üzenetek fogadása
ws.onmessage = function (event) {
    const data = JSON.parse(event.data);
    console.log("WebSocket üzenet érkezett:", data);

    // Táblázat frissítése az új adatokkal
    if (data && data.material_orders) {
        updateTable(data.material_orders);
    }
};

// Hiba kezelése
ws.onerror = function (error) {
    console.error("WebSocket hiba:", error);
};

// Kapcsolat bezárása
ws.onclose = function () {
    console.log("WebSocket kapcsolat megszakadt.");
};

// Táblázat frissítése
function updateTable(orders) {
    const tableBody = document.querySelector("#orders-table tbody");
    tableBody.innerHTML = ""; // Töröljük a régi sorokat

    orders.forEach(order => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${order.AUFTRAGNR}</td>
            <td>${order.ANLIEF_PUNKT}</td>
            <td>${order.MATNR}</td>
            <td>${order.ANF_DATE}</td>
            <td>${order.ANF_TIME}</td>
            <td>${order.PLAN_ANL_DATE}</td>
            <td>${order.PLAN_ANL_TIME}</td>
            <td>${order.OBJKEY}</td>
            <td>${order.MATBEZ}</td>
            <td>${order.STATUS}</td>
            <td>${order.LAGERPLATZ}</td>
            <td>${order.MENGE}</td>
            <td>${order.FIFOKEY}</td>
        `;
        tableBody.appendChild(row);
    });
}
