import threading
import subprocess
import webview
import logging

# Naplózás beállítása
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("application.log"),
        logging.StreamHandler()
    ]
)

def start_django():
    """Django szerver indítása és naplózása."""
    try:
        logging.info("Django szerver indítása...")
        process = subprocess.Popen(
            ['python', 'manage.py', 'runserver'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        for line in process.stdout:
            logging.info(f"Django: {line.strip()}")
        for line in process.stderr:
            logging.error(f"Django Error: {line.strip()}")
    except Exception as e:
        logging.error(f"Django indítása közben hiba történt: {e}")

def start_celery():
    """Celery munkás indítása és naplózása."""
    try:
        logging.info("Celery munkás indítása...")
        process = subprocess.Popen(
            ['celery', '-A', 'production_supply', 'worker', '--loglevel=info'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        for line in process.stdout:
            logging.info(f"Celery: {line.strip()}")
        for line in process.stderr:
            logging.error(f"Celery Error: {line.strip()}")
    except Exception as e:
        logging.error(f"Celery indítása közben hiba történt: {e}")

if __name__ == '__main__':
    # Django és Celery indítása külön szálakon
    threading.Thread(target=start_django, daemon=True).start()
    threading.Thread(target=start_celery, daemon=True).start()

    # Pywebview ablak megnyitása
    try:
        logging.info("Pywebview ablak indítása...")
        webview.create_window("Production Supply", "http://127.0.0.1:8000")
        webview.start()
    except Exception as e:
        logging.error(f"Pywebview indítása közben hiba történt: {e}")
