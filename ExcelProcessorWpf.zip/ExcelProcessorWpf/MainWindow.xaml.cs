﻿// MainWindow.xaml.cs - teljes javított változat
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using System.Threading.Tasks;
using ExcelProcessorWpf.Models;

namespace ExcelProcessorWpf
{
    public partial class MainWindow : Window
    {
        private Dictionary<string, string> directories;
        private List<string> filePaths = new();

        public MainWindow()
        {
            InitializeComponent();
            LoadNames();
            directories = GetDirectoryPaths();
        }

        private void LoadNames()
        {
            try
            {
                var json = File.ReadAllText("config.json");
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                var names = root.GetProperty("names").EnumerateArray().Select(n => n.GetString()).Where(n => n != null).ToList();
                NameComboBox.ItemsSource = names;
                NameComboBox.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                Log($"Hiba a nevek betöltésekor: {ex.Message}");
            }
        }

        private Dictionary<string, string> GetDirectoryPaths()
        {
            int year = DateTime.Now.Year;
            int quarter = (DateTime.Now.Month - 1) / 3 + 1;
            string basePath = @"w:\\TERMELES";
            return new Dictionary<string, string>
            {
                { "Üzemrész 1", $"{basePath}\\002_1-es_uzem\\02_Gyártástervezés\\{year}\\{quarter}.negyedév" },
                { "Üzemrész 2", $"{basePath}\\003_2-es üzem\\02_Gyártástervezés\\{year}\\{quarter}.negyedév" },
                { "Üzemrész 3", $"{basePath}\\004_3-as üzem\\02_Gyártástervezés\\{year}\\{quarter}.negyedév" },
                { "Üzemrész 4", $"{basePath}\\005_4-es üzem\\02_Gyártástervezés\\{year}\\{quarter}.negyedév" },
            };
        }

        private void OpenFileDialog_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button?.Tag is string selectedDirectory)
            {
                var dialog = new OpenFileDialog
                {
                    Title = "Válassz Excel fájlokat",
                    Filter = "Excel Files (*.xlsx)|*.xlsx",
                    Multiselect = true,
                    InitialDirectory = selectedDirectory
                };

                if (dialog.ShowDialog() == true)
                {
                    filePaths = dialog.FileNames.ToList();
                    _ = ProcessFiles();
                }
            }
        }

        private async Task ProcessFiles()
        {
            if (!filePaths.Any()) return;

            var shiftsDict = new Dictionary<string, bool>
            {
                { "DE", CheckDE.IsChecked == true },
                { "DU", CheckDU.IsChecked == true },
                { "ÉJ", CheckEJ.IsChecked == true },
            };

            // 🔍 Validáció: legalább egy műszak legyen kiválasztva
            if (!shiftsDict.Any(x => x.Value))
            {
                Log("⚠ Nincs kiválasztva egy műszak sem. Jelöld be legalább az egyiket.");
                return;
            }


            bool printEnabled = CheckPrintPip.IsChecked == true;
            string selectedName = NameComboBox.SelectedItem?.ToString() ?? "";

            var processor = new ExcelProcessor(
                filePaths,
                new List<string> { "Gép neve", "SAP nr.", "db/műszak", "Anyag", "Műszak", "Teljesítmény" },
                shiftsDict,
                printEnabled,
                selectedName
            );

            processor.ReportProgress += msg => Log(msg);
            processor.ReportFinished += success =>
            {
                Log(success ? "Feldolgozás befejezve." : "Hiba történt a feldolgozás során.");
            };

            await processor.RunAsync();
        }

        private void Log(string message)
        {
            Dispatcher.Invoke(() =>
            {
                LogBox.AppendText($"{DateTime.Now:HH:mm:ss} - {message}\n");
                LogBox.ScrollToEnd();
            });
        }
    }
}
