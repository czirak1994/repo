using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Spire.Xls;

namespace ExcelProcessorWpf.Models
{
    public class ExcelProcessor
    {
        private readonly List<string> _filePaths;
        private readonly List<string> _columnsToKeep;
        private readonly Dictionary<string, bool> _filterShifts;
        private readonly bool _enablePrint;
        private readonly string _displayName;

        public Action<string>? ReportProgress;
        public Action<bool>? ReportFinished;

        public ExcelProcessor(List<string> filePaths, List<string> columnsToKeep, Dictionary<string, bool> filterShifts, bool enablePrint, string displayName)
        {
            _filePaths = filePaths;
            _columnsToKeep = columnsToKeep;
            _filterShifts = filterShifts;
            _enablePrint = enablePrint;
            _displayName = displayName;
        }

        public async Task RunAsync()
        {
            try
            {
                var results = new List<(string, List<Dictionary<string, string>>)>();

                foreach (var path in _filePaths)
                {
                    ReportProgress?.Invoke($"Feldolgozás: {path}");
                    var data = await Task.Run(() => ProcessFile(path));
                    if (data != null)
                        results.AddRange(data);
                }

                if (results.Count > 0)
                {
                    SaveAndPrintResults(results);
                    foreach (var (_, df) in results)
                        FillPipSheetAndPrint(df);
                }

                ReportFinished?.Invoke(true);
            }
            catch (Exception ex)
            {
                ReportProgress?.Invoke($"Hiba: {ex.Message}");
                ReportFinished?.Invoke(false);
            }
        }

        private List<(string, List<Dictionary<string, string>>)>? ProcessFile(string filePath)
        {
            var results = new List<(string, List<Dictionary<string, string>>)>();
            var workbook = new Workbook();
            workbook.LoadFromFile(filePath);

            foreach (Worksheet sheet in workbook.Worksheets)
            {
                string sheetName = sheet.Name;
                if (!sheetName.Contains("0291_"))
                    continue;

                ReportProgress?.Invoke($"Lap feldolgozása: {sheetName}");

                var data = new List<Dictionary<string, string>>();
                int startRow = -1, endRow = -1;

                for (int i = 1; i <= sheet.LastRow; i++)
                {
                    for (int j = 1; j <= sheet.LastColumn; j++)
                    {
                        var value = sheet[i, j].Text;
                        if (value == "StartDataFrame") startRow = i;
                        if (value == "EndDataFrame") endRow = i;
                    }
                }

                if (startRow == -1 || endRow == -1 || startRow >= endRow)
                {
                    ReportProgress?.Invoke($"Hiba: Start/End nem található a {sheetName} lapon.");
                    continue;
                }

                var headers = new List<string>();
                for (int col = 1; col <= sheet.LastColumn; col++)
                    headers.Add(sheet[startRow + 1, col].Text ?? $"Col{col}");

                for (int row = startRow + 2; row < endRow; row++)
                {
                    var dict = new Dictionary<string, string>();
                    bool hasData = false;

                    for (int col = 1; col <= sheet.LastColumn; col++)
                    {
                        string header = headers[col - 1];
                        string cell = sheet[row, col].Text;
                        if (!string.IsNullOrWhiteSpace(cell))
                        {
                            dict[header] = cell;
                            hasData = true;
                        }
                    }

                    if (hasData)
                        data.Add(dict);
                }

                // Szűrés – dátumoszlopokra és értékekre
                var today = DateTime.Today;

                var dateColumns = headers
                    .Where(h =>
                        DateTime.TryParse(h, out var parsed) &&
                        parsed.Date == today
                    )
                    .ToList();


                if (!dateColumns.Any())
                {
                    ReportProgress?.Invoke($"⚠ A mai dátum ({today}) nem található egyik oszlopban sem a(z) {sheetName} lapon.");
                    continue;
                }

                var cleanData = data
                    .Where(row =>
                        dateColumns.All(col =>
                            row.TryGetValue(col, out var val) &&
                            !string.IsNullOrWhiteSpace(val) &&
                            val != "0" &&
                            !val.ToLower().Contains("nan") &&
                            !val.Contains("%")
                        )
                    ).ToList();

                // Műszak szűrés
                var validShifts = _filterShifts.Where(kvp => kvp.Value).Select(kvp => kvp.Key).ToHashSet();
                var shiftFiltered = cleanData
                    .Where(row => row.TryGetValue("Műszak", out var shift) && validShifts.Contains(shift))
                    .ToList();

                var filtered = shiftFiltered
                    .Select(row => _columnsToKeep.ToDictionary(k => k, k => row.ContainsKey(k) ? row[k] : ""))
                    .ToList();

                results.Add((sheetName, filtered));
            }

            return results;
        }

        private void FillPipSheetAndPrint(List<Dictionary<string, string>> data)
        {
            if (!_enablePrint) return;

            foreach (var row in data)
            {
                try
                {
                    string tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString() + ".xlsx");

                    var wb = new Workbook();
                    wb.LoadFromFile("PIP_lap.xlsx");

                    var ws = wb.Worksheets[0];
                    ws.Range["E2"].Text = DateTime.Now.ToString("yyyy-MM-dd");
                    ws.Range["E3"].Text = _displayName;
                    ws.Range["E4"].Text = row.GetValueOrDefault("Gép neve", "nincs adat");
                    ws.Range["E6"].Text = row.GetValueOrDefault("SAP nr.", "nincs adat");
                    ws.Range["G6"].Text = row.GetValueOrDefault("Anyag", "nincs adat");

                    wb.SaveToFile(tempPath, FileFormat.Version2013);

                    Type excelType = Type.GetTypeFromProgID("Excel.Application");
                    if (excelType == null)
                    {
                        ReportProgress?.Invoke("Excel nem elérhető a rendszerben (PIP lap nyomtatás).");
                        continue;
                    }

                    dynamic excel = Activator.CreateInstance(excelType);
                    excel.Visible = false;
                    excel.DisplayAlerts = false;

                    dynamic workbooks = excel.Workbooks;
                    dynamic workbook = workbooks.Open(tempPath);
                    dynamic worksheet = workbook.Worksheets[1];

                    worksheet.PageSetup.Orientation = 2;
                    worksheet.PageSetup.TopMargin = excel.InchesToPoints(1);
                    worksheet.PageSetup.BottomMargin = excel.InchesToPoints(0.5);
                    worksheet.PageSetup.LeftMargin = excel.InchesToPoints(0.2);
                    worksheet.PageSetup.RightMargin = excel.InchesToPoints(0.2);
                    worksheet.PageSetup.FitToPagesWide = 1;
                    worksheet.PageSetup.FitToPagesTall = false;
                    worksheet.PageSetup.CenterHorizontally = true;
                    worksheet.PageSetup.CenterVertically = true;
                    worksheet.PageSetup.CenterHeader = $"&C&\"Arial,Bold\"&14 PIP lap – {_displayName} – {DateTime.Now:yyyy-MM-dd HH:mm}";

                    worksheet.PrintOut();

                    workbook.Close(false);
                    excel.Quit();

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workbooks);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);
                }
                catch (Exception ex)
                {
                    ReportProgress?.Invoke($"Nyomtatási hiba (PIP): {ex.Message}");
                }
            }
        }

        private void SaveAndPrintResults(List<(string SheetName, List<Dictionary<string, string>> Rows)> results)
        {
            try
            {
                var tempPath = Path.Combine(Path.GetTempPath(), "summary_" + Guid.NewGuid() + ".xlsx");

                var wb = new Workbook();
                var ws = wb.Worksheets[0];
                ws.Name = "Összesített Adatok";

                int row = 1;

                foreach (var (sheetName, data) in results)
                {
                    ws.Range[row, 1].Text = sheetName;
                    ws.Range[row, 1].Style.Font.IsBold = true;
                    row++;

                    if (data.Count > 0)
                    {
                        var headers = data[0].Keys.ToList();

                        for (int i = 0; i < headers.Count; i++)
                        {
                            ws.Range[row, i + 1].Text = headers[i];
                            ws.Range[row, i + 1].Style.Font.IsBold = true;
                            ws.Range[row, i + 1].Style.HorizontalAlignment = HorizontalAlignType.Center;
                            ws.Range[row, i + 1].BorderAround(LineStyleType.Thin);
                        }

                        row++;

                        foreach (var dict in data)
                        {
                            for (int i = 0; i < headers.Count; i++)
                            {
                                string val = dict.GetValueOrDefault(headers[i], "");
                                ws.Range[row, i + 1].Text = val;
                                ws.Range[row, i + 1].BorderAround(LineStyleType.Thin);
                            }
                            row++;
                        }

                        row += 2;
                    }
                }

                ws.AllocatedRange.AutoFitColumns();
                ws.PageSetup.Orientation = PageOrientationType.Landscape;

                wb.SaveToFile(tempPath, FileFormat.Version2013);

                Type excelType = Type.GetTypeFromProgID("Excel.Application");
                if (excelType == null)
                {
                    ReportProgress?.Invoke("Excel nem elérhető a rendszerben (összesítő nyomtatás).");
                    return;
                }

                dynamic excel = Activator.CreateInstance(excelType);
                excel.Visible = false;
                excel.DisplayAlerts = false;

                dynamic workbooks = excel.Workbooks;
                dynamic workbook = workbooks.Open(tempPath);
                dynamic worksheet = workbook.Worksheets[1];

                worksheet.PageSetup.Orientation = 2;
                worksheet.PageSetup.TopMargin = excel.InchesToPoints(1);
                worksheet.PageSetup.BottomMargin = excel.InchesToPoints(0.5);
                worksheet.PageSetup.LeftMargin = excel.InchesToPoints(0.2);
                worksheet.PageSetup.RightMargin = excel.InchesToPoints(0.2);
                worksheet.PageSetup.FitToPagesWide = 1;
                worksheet.PageSetup.FitToPagesTall = false;
                worksheet.PageSetup.CenterHorizontally = true;
                worksheet.PageSetup.CenterVertically = true;
                worksheet.PageSetup.CenterHeader = $"&C&\"Arial,Bold\"&16 Gyártásterv – {DateTime.Now:yyyy-MM-dd HH:mm:ss}";

                worksheet.PrintOut();

                workbook.Close(false);
                excel.Quit();

                System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbooks);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);
            }
            catch (Exception ex)
            {
                ReportProgress?.Invoke($"Hiba az összesítés során: {ex.Message}");
            }
        }
    }
}
