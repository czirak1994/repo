﻿using System.Windows;

namespace ExcelProcessorWpf
{
    public partial class App : Application
    {
    }
}
