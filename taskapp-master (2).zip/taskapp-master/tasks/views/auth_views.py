from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout

def login_view(request):
    login_failed = False  # Track if the login failed

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        
        if user:
            login(request, user)
            # Redirect based on user group
            if user.groups.filter(name='keszletezo').exists():
                return redirect('tasks')
            elif user.groups.filter(name='raktaros').exists():
                return redirect('receiver')
            elif user.groups.filter(name='shift_leader').exists():
                return redirect('shift_leader')
            return redirect('home')
        
        # If authentication fails, set login_failed to True
        login_failed = True

    return render(request, 'login.html', {'login_failed': login_failed})

def logout_view(request):
    logout(request)
    return redirect('login')
