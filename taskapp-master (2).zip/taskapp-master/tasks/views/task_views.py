import logging
from django.shortcuts import render, redirect
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets
from tasks.models import Task, TaskTitle, TaskGroup
from django.contrib.auth.models import User
from tasks.serializers import TaskSerializer, TaskTitleSerializer, TaskGroupSerializer
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib.sessions.models import Session
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
import json

logger = logging.getLogger(__name__)

class TaskTitleViewSet(viewsets.ModelViewSet):
    queryset = TaskTitle.objects.all()
    serializer_class = TaskTitleSerializer

class TaskGroupViewSet(viewsets.ModelViewSet):
    queryset = TaskGroup.objects.all()
    serializer_class = TaskGroupSerializer

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

    def perform_create(self, serializer):
        try: 
            task = serializer.save()
        except Exception as e:
            print(f"Task creation error: {e}")     
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
        # Send a message over the WebSocket connection
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            'tasks',  # This should match the group name in your consumer
            {
                'type': 'task.created',
                'task': {
                    'id': task.id,
                    'title': task.title,
                    'description': task.description,
                    # ... any other task fields you want to include ...
                },
            }
        )
@login_required
def list_tasks(request):
    task_groups = {}
    for task_title in TaskTitle.objects.all():
        group_name = task_title.task_group.name
        if group_name not in task_groups:
            task_groups[group_name] = []
        task_groups[group_name].append(task_title)
    return render(request, 'tasks.html', {'task_groups': task_groups})

def create_task(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        Task.objects.create(title=title, description=description, created_by=request.user.username)
        return redirect('list-tasks')

@login_required
def receiver_view(request):
    return render(request, 'receiver.html', {'user': request.user})

def get_logged_in_users(request):
    try:
        active_sessions = Session.objects.filter(expire_date__gte=timezone.now())
        user_ids = [session.get_decoded().get('_auth_user_id') for session in active_sessions if session.get_decoded().get('_auth_user_id')]
        users = User.objects.filter(id__in=user_ids)
        user_data = [{"id": user.id, "username": user.username} for user in users]
        return JsonResponse(user_data, safe=False)
    except Exception as e:
        logger.error(f"Error fetching logged-in users: {e}")
        return JsonResponse({'error': 'Failed to retrieve logged-in users'}, status=500)   

@csrf_exempt
def get_tasks(request):
    tasks = Task.objects.all()
    tasks_data = [
        {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "is_selected": task.is_selected,
            "selected_by": task.selected_by,
            "completed": task.completed,
            "created_by": task.created_by
        }
        for task in tasks
    ]
    return JsonResponse({"tasks": tasks_data}, safe=False)    

def warehouse_tasks_view(request):
    try:
        # Lekérjük a "Raktár" nevű TaskGroup-ot
        warehouse_group = TaskGroup.objects.get(name="Raktár")
        
        # Szűrjük a Task objektumokat a TaskTitle és TaskGroup kapcsolaton keresztül
        warehouse_task_titles = TaskTitle.objects.filter(task_group=warehouse_group)
        warehouse_tasks = Task.objects.filter(title__in=warehouse_task_titles.values_list('title', flat=True))

        # JSON válasz létrehozása
        tasks_data = [
            {
                "id": task.id,
                "title": task.title,
                "description": task.description,
                "created_by": task.created_by,
                "created_at": task.created_at,
                "completed": task.completed,
                "completed_by": task.completed_by,
                "updated_at": task.updated_at,
                "is_selected": task.is_selected,
                "selected_by": task.selected_by
            }
            for task in warehouse_tasks
        ]
        return JsonResponse(tasks_data, safe=False)

    except TaskGroup.DoesNotExist:
        return JsonResponse({"error": "Raktár csoport nem található."}, status=404)    