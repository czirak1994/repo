# tasks/signals.py
from django.db.models.signals import post_migrate
from django.dispatch import receiver
from .models import TaskGroup

@receiver(post_migrate)
def create_default_task_group(sender, **kwargs):
    if sender.name == "tasks":  # Csak akkor fusson, ha a `tasks` alkalmazás van migrálva
        TaskGroup.objects.get_or_create(name="Raktár")
