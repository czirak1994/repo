# tasks/urls.py
from django.urls import path, include
from .views import (
    login_view, logout_view, shift_leader_view, list_tasks, 
    create_task, receiver_view, complete_tasks, select_task, 
    get_logged_in_users, assign_task_to_user, get_tasks,
    TaskViewSet, TaskTitleViewSet, TaskGroupViewSet, 
    create_warehouse_task, warehouse_tasks_view
)
from rest_framework.routers import DefaultRouter

# Set up the REST API router
router = DefaultRouter()
router.register(r'tasks', TaskViewSet)
router.register(r'tasktitles', TaskTitleViewSet)
router.register(r'taskgroups', TaskGroupViewSet)

urlpatterns = [
    # REST API endpoints
    path('api/', include(router.urls)),
    path('api/warehouse_tasks/', warehouse_tasks_view, name='warehouse_tasks'),
    path('api/create-warehouse-task/', create_warehouse_task, name='create_warehouse_task'),
    path('api/get-tasks/', get_tasks, name='get_tasks'),

    # Authentication and app-specific views
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('', list_tasks, name='tasks'),  # Default route for task list
    path('create/', create_task, name='task-create'),
    path('receiver/', receiver_view, name='receiver'),
    path('shift_leader/', shift_leader_view, name='shift_leader'),

    # Additional task-related endpoints
    path('api/complete-tasks/', complete_tasks, name='complete_tasks'),
    path('api/select-task/', select_task, name='select_task'),
    path('api/get_logged_in_users/', get_logged_in_users, name='get_logged_in_users'),
    path('api/assign_task_to_user/', assign_task_to_user, name='assign_task_to_user'),
]

