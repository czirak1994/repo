// CSRF token helper function
function getCookie(name) {
    const cookieValue = document.cookie.split('; ').find(row => row.startsWith(name + '='));
    return cookieValue ? decodeURIComponent(cookieValue.split('=')[1]) : null;
}

// Logout function
function logout() {
    fetch('/tasks/logout/', {
        method: "POST",
        headers: {
            "X-CSRFToken": getCookie('csrftoken'),
        },
        body: new URLSearchParams({
            csrfmiddlewaretoken: getCookie('csrftoken')
        })
    }).then(response => {
        if (response.ok) window.location.href = "/tasks/login/";
    }).catch(error => console.error('Logout error:', error));
}

// Load and display task titles grouped by category
function loadTaskTitles() {
    fetch('/tasks/api/tasktitles/')
        .then(response => response.json())
        .then(data => {
            const taskList = document.getElementById('task-list');
            const groups = {};
            data.forEach(taskTitle => {
                const groupName = taskTitle.task_group_name || 'Névtelen csoport';
                if (!groups[groupName]) groups[groupName] = [];
                groups[groupName].push(taskTitle);
            });
            Object.entries(groups).forEach(([groupName, tasks]) => {
                const groupButton = document.createElement('button');
                groupButton.className = 'collapsible';
                groupButton.textContent = groupName;
                taskList.appendChild(groupButton);

                const groupContent = document.createElement('div');
                groupContent.className = 'content';
                tasks.forEach(taskTitle => {
                    const button = document.createElement('button');
                    button.className = 'task-button';
                    button.dataset.taskTitle = taskTitle.title;
                    button.textContent = taskTitle.title;
                    button.addEventListener('click', function() {
                        this.classList.toggle('selected');
                        updateSelectedTasks(this);
                    });
                    groupContent.appendChild(button);
                });
                taskList.appendChild(groupContent);
                groupButton.addEventListener('click', function() {
                    this.classList.toggle("active");
                    this.nextElementSibling.style.display = this.nextElementSibling.style.display === "block" ? "none" : "block";
                });
            });
        })
        .catch(error => console.error('Error fetching task titles:', error));
}

// Update selected tasks in the confirmation dialog
// Kiválasztott feladatok dinamikus frissítése a megerősítő ablakban
function updateSelectedTasks(taskButton) {
    const selectedTasksList = document.getElementById('selected-tasks-list');

    if (!selectedTasksList) {
        console.error("Required DOM element for updating tasks is missing.");
        return;
    }

    if (taskButton.classList.contains('selected')) {
        // If selected, add to confirmation list
        const taskItem = document.createElement('div');
        taskItem.classList.add('selected-task-item');
        taskItem.textContent = taskButton.dataset.taskTitle;
        taskItem.dataset.taskTitle = taskButton.dataset.taskTitle;

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.classList.add('remove-button');
        removeButton.addEventListener('click', function() {
            taskItem.remove();
            taskButton.classList.remove('selected');
        });

        taskItem.appendChild(removeButton);
        selectedTasksList.appendChild(taskItem);
    } else {
        // If not selected, remove from confirmation list
        const existingTaskItem = Array.from(selectedTasksList.children).find(
            item => item.dataset.taskTitle === taskButton.dataset.taskTitle
        );
        if (existingTaskItem) {
            existingTaskItem.remove();
        }
    }
    // Győződjünk meg róla, hogy a megerősítő ablak mindig látható
    document.getElementById('confirmation-dialog').style.display = 'block';
}



// Send selected tasks
document.getElementById('confirm-send').addEventListener('click', function() {
    const selectedTasks = document.querySelectorAll('#selected-tasks-list .selected-task-item');
    const csrftoken = getCookie('csrftoken');
    const username = window.username || "defaultUser";

    const promises = Array.from(selectedTasks).map(taskItem => fetch('/tasks/api/tasks/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken
        },
        body: JSON.stringify({
            title: taskItem.dataset.taskTitle,
            description: "1",
            created_by: username
        })
    }).then(response => {
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return response.json();
    }));

    Promise.all(promises)
        .then(results => {
            console.log('Tasks sent:', results);
            // Itt tisztítsuk meg a kijelölt feladatok listáját, de ne zárjuk be a megerősítő ablakot
            document.getElementById('selected-tasks-list').innerHTML = '';
            document.querySelectorAll('.task-button.selected').forEach(button => button.classList.remove('selected'));
        })
        .catch(e => console.error('Error sending tasks:', e.message));
});


// Cancel sending tasks and clear selection
document.getElementById('cancel-send').addEventListener('click', function() {
    document.getElementById('confirmation-dialog').style.display = 'none';
    document.getElementById('selected-tasks-list').innerHTML = '';
    document.querySelectorAll('.task-button.selected').forEach(button => button.classList.remove('selected'));
});

// Load tasks on page load
document.addEventListener('DOMContentLoaded', loadTaskTitles);
