// CSRF token lekérdezése
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
// Kijelentkezés kezelése
function logout() {
    fetch('/tasks/logout/', {  // Az útvonalat abszolút URL-ként add meg
        method: "POST",
        headers: {
            "X-CSRFToken": getCookie('csrftoken'),
        },
        body: new URLSearchParams({
            csrfmiddlewaretoken: getCookie('csrftoken')
        })
    }).then(response => {
        if (response.ok) {
            window.location.href = "/tasks/login/";  // Kijelentkezés után átirányítás a kezdőlapra
        }
    }).catch(error => {
        console.error('Error:', error);
    });
}
// Felhasználók betöltése
function loadUsers() {
    fetch('/tasks/api/get_logged_in_users/')
        .then(response => response.json())
        .then(users => {
            const userSelect = document.getElementById('user-select');
            userSelect.innerHTML = '<option value="">Nincs kiválasztva</option>';
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user.id;
                option.textContent = user.username;
                userSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error fetching users:', error));
}

// Feladatcímek betöltése
function loadTaskTitles() {
    fetch('/tasks/api/tasktitles/')
        .then(response => response.json())
        .then(data => {
            const taskList = document.getElementById('task-list');
            const groups = {};
            data.forEach(taskTitle => {
                const groupName = taskTitle.task_group_name || 'Névtelen csoport';
                if (!groups[groupName]) {
                    groups[groupName] = [];
                }
                groups[groupName].push(taskTitle);
            });
            for (const [groupName, tasks] of Object.entries(groups)) {
                const groupButton = document.createElement('button');
                groupButton.className = 'collapsible';
                groupButton.textContent = groupName;
                taskList.appendChild(groupButton);

                const groupContent = document.createElement('div');
                groupContent.className = 'content';
                tasks.forEach(taskTitle => {
                    const button = document.createElement('button');
                    button.className = 'task-button';
                    button.dataset.taskTitle = taskTitle.title;
                    button.textContent = taskTitle.title;
                    button.addEventListener('click', function() {
                        this.classList.toggle('selected');
                        updateSelectedTasks(); // Automatikus frissítés és megjelenítés
                    });
                    groupContent.appendChild(button);
                });
                taskList.appendChild(groupContent);
                groupButton.addEventListener('click', function() {
                    this.classList.toggle("active");
                    groupContent.style.display = groupContent.style.display === "block" ? "none" : "block";
                });
            }
        })
        .catch(error => console.error('Error fetching task titles:', error));
}

// Kiválasztott feladatok frissítése
function updateSelectedTasks() {
    const selectedTasks = document.querySelectorAll('.task-button.selected');
    const selectedTasksList = document.getElementById('selected-tasks-list');

    selectedTasks.forEach(task => {
        const title = task.dataset.taskTitle;

        // Ellenőrizni, hogy a feladat már benne van-e a megerősítő ablakban
        const isDuplicate = Array.from(selectedTasksList.children).some(item => item.dataset.taskTitle === title);

        if (!isDuplicate) { // Csak akkor adja hozzá, ha nem duplikált
            const taskItem = document.createElement('div');
            taskItem.classList.add('selected-task-item');
            taskItem.textContent = title;
            taskItem.dataset.taskTitle = title;

            const removeButton = document.createElement('button');
            removeButton.textContent = 'Eltávolítás';
            removeButton.classList.add('remove-button');
            removeButton.addEventListener('click', function() {
                task.classList.remove('selected');
                taskItem.remove();
            });

            taskItem.appendChild(removeButton);
            selectedTasksList.appendChild(taskItem);
        }
    });
}

// Manuális feladat hozzáadása
document.getElementById('add-manual-task').addEventListener('click', function() {
    const manualTitleInput = document.getElementById('manual-title-input');
    const title = manualTitleInput.value.trim();
    
    if (title) {
        const selectedTasksList = document.getElementById('selected-tasks-list');
        
        // Ellenőrizni, hogy a manuálisan hozzáadott feladat már szerepel-e a listában
        const isDuplicate = Array.from(selectedTasksList.children).some(task => task.dataset.taskTitle === title);

        if (!isDuplicate) {
            const taskItem = document.createElement('div');
            taskItem.classList.add('selected-task-item');
            taskItem.textContent = title;
            taskItem.dataset.taskTitle = title;
            manualTitleInput.value = ''; // Törlés az input mezőből

            const removeButton = document.createElement('button');
            removeButton.textContent = 'Eltávolítás';
            removeButton.classList.add('remove-button');
            removeButton.addEventListener('click', function() {
                taskItem.remove();
            });

            taskItem.appendChild(removeButton);
            selectedTasksList.appendChild(taskItem);
            document.getElementById('confirmation-dialog').style.display = 'block'; // Megerősítő ablak megjelenítése
        } else {
            alert('Ez a feladat már szerepel a kiválasztottak között.');
        }
    }
});

// Feladatok elküldése
document.getElementById('confirm-send').addEventListener('click', function() {
    const selectedTasks = document.querySelectorAll('#selected-tasks-list .selected-task-item');
    const csrftoken = getCookie('csrftoken');
    const userId = document.getElementById('user-select').value;

    const promises = Array.from(selectedTasks).map(taskItem => {
        const url = userId ? '/tasks/api/create-warehouse-task/' : '/tasks/api/tasks/';
        const taskData = {
            title: taskItem.dataset.taskTitle,
            description: "Feladat leírás",
            created_by: username
        };
        if (userId) {
            taskData.user_id = userId;
        }

        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken
            },
            body: JSON.stringify(taskData)
        }).then(response => {
            if (!response.ok) {
                response.text().then(text => console.error("Hibaüzenet a szervertől:", text));
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        });
    });

    Promise.all(promises)
        .then(results => {
            console.log('Feladatok sikeresen elküldve:', results);

            // Megerősítő ablak újra beállítása
            document.getElementById('confirmation-dialog').style.display = 'none';

            // Kiválasztott feladatok listájának törlése
            const selectedTasksList = document.getElementById('selected-tasks-list');
            selectedTasksList.innerHTML = '';

            // Manuális és kiválasztott feladatok listájának alaphelyzetbe állítása
            document.querySelectorAll('.task-button.selected').forEach(button => button.classList.remove('selected'));

            // A megerősítő ablak újra megjelenítése
            document.getElementById('confirmation-dialog').style.display = 'block';
        })
        .catch(e => {
            console.error('Hiba a feladatok elküldésekor:', e.message);
        });
});


// Betöltés eseménykezelője
document.addEventListener('DOMContentLoaded', () => {
    loadTaskTitles();
    loadUsers();
});
