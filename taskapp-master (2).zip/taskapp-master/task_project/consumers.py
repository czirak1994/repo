#consumers.py
import json
from channels.generic.websocket import AsyncWebsocketConsumer

class TaskConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        if self.scope["user"].is_authenticated:
            await self.channel_layer.group_add("tasks", self.channel_name)
            await self.accept()
        else:
            await self.close(code=4001)

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard("tasks", self.channel_name)

    # Esemény kezelése, amikor egy új feladat jön létre
    async def task_created(self, event):
        await self.send(text_data=json.dumps({
            'type': 'task_created',
            'task': event['task']
        }))

    # Esemény kezelése, amikor egy feladatot kiválasztanak
    async def task_selected_event(self, event):
        await self.send(text_data=json.dumps({
            'type': 'task_selected',
            'task_id': event['task_id'],
            'username': event['username']
        }))

    # Esemény kezelése, amikor egy feladatot feloldanak
    async def task_deselected_event(self, event):
        await self.send(text_data=json.dumps({
            'type': 'task_deselected',
            'task_id': event['task_id']
        }))

    # Esemény kezelése, amikor egy feladatot teljesítenek
    async def task_completed(self, event):
        await self.send(text_data=json.dumps({
            'type': 'task_completed',
            'task_id': event['task_id']
        }))


class WarehouseTaskConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        user = self.scope["user"]
        if user.is_authenticated:
            self.group_name = f"user_{user.id}"
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def warehouse_task_created(self, event):
        await self.send(text_data=json.dumps({
            'type': 'warehouse_task_created',
            'task': event['task']
        }))
