from django.urls import path
from task_project import consumers  # Import a projekt mappából

websocket_urlpatterns = [
    path('wss/tasks/', consumers.TaskConsumer.as_asgi()),
    path('wss/warehouse_tasks/', consumers.WarehouseTaskConsumer.as_asgi()),
]
