document.addEventListener('DOMContentLoaded', () => {
    loadMachines();
});

function loadMachines() {
    // API hívás a gépek betöltéséhez
    fetch('/machines/api/machines/')
        .then(response => {
            if (!response.ok) throw new Error('Failed to fetch machines');
            return response.json();
        })
        .then(data => {
            const machineSelector = document.getElementById('machineSelector');
            data.forEach(machine => {
                const option = document.createElement('option');
                option.value = machine.id;
                option.textContent = machine.name;
                machineSelector.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error fetching machines:', error);
        });
}

function loadPlansForMachine() {
    const machineId = document.getElementById('machineSelector').value;
    if (!machineId) return;

    // API hívás a géphez tartozó gyártástervek betöltésére
    fetch(`/api/plans/?machine_id=${machineId}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to fetch plans');
            return response.json();
        })
        .then(data => {
            const plansTableBody = document.getElementById('plansTable').querySelector('tbody');
            plansTableBody.innerHTML = ''; // Tisztítás

            data.forEach(plan => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${plan.id}</td>
                    <td>${plan.machine_name}</td>
                    <td>${plan.status}</td>
                    <td>${plan.start_date}</td>
                    <td>${plan.end_date}</td>
                `;
                plansTableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error fetching plans:', error);
        });
}

function navigateTo(section) {
    alert(`Navigating to: ${section}`);
}
