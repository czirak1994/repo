from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def home_view(request):
    """
    A production app kezdőlapja.
    Csak bejelentkezett felhasználók érhetik el.
    """
    return render(request, 'production/home.html', {
        'username': request.user.username,
        'role': request.user.role
    })
