from pyrfc import Connection
from django.conf import settings

class SAPConnectionManager:
    _connection = None

    @classmethod
    def initialize_connection(cls, user, password):
        """
        Inicializálja az SAP kapcsolatot az űrlap adatai alapján.
        """
        try:
            # SAP kapcsolat inicializálása dinamikusan generált snc_myname értékkel
            cls._connection = Connection(
                user=user,
                passwd=password,
                ashost=settings.SAP_CONNECTION['ashost'],
                sysnr=settings.SAP_CONNECTION['sysnr'],
                client=settings.SAP_CONNECTION['client'],
                lang=settings.SAP_CONNECTION['lang'],
            )
            # rfc_ping hívás a kapcsolat tesztelésére
            cls._connection.ping()
        except Exception as e:
            cls._connection = None
            raise Exception(f"SAP Connection initialization or ping failed: {str(e)}")

    @classmethod
    def get_connection(cls):
        """
        Visszaadja a kapcsolatot.
        """
        if cls._connection is None:
            raise Exception("SAP connection is not initialized.")
        return cls._connection

    @classmethod
    def close_connection(cls):
        """
        Kapcsolat bezárása.
        """
        if cls._connection:
            cls._connection.close()
            cls._connection = None
