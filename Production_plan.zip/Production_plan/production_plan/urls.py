# project/urls.py
from django.urls import path, include

urlpatterns = [
    
    path('users/', include('users.urls')),
    path('machines/', include('machines.urls')),
    path('production/', include('production.urls')),
]

