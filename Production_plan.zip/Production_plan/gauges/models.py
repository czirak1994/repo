from django.db import models

class Gauge(models.Model):
    traceability = models.CharField(max_length=100, unique=True) #Traceability value
    device_name = models.CharField(max_length=100)
    device_description = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.traceability}{self.device_name}{self.device_description}" 

    
