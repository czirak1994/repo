# gauges/utils.py
from sap_functions.services import SAPConnectionManager

def get_sap_traceability_data(self, statuses=['01', '02']):
    """
    Traceability adatok lekérése az SAP-ból.
    """
    try:
        combined_data = []  # Store combined results from all statuses

        for status in self.statuses:
            if not self._is_running:
                break  # Exit loop if the thread is stopped

            # SAP call with the current status as a parameter
            parameters = {"I_STATUS": status, "I_WERKS": "0291"}
            result = self.sap_connection.call(
                "ZTRB_DB_EMERGENCY_READ", **parameters
            )
            e_ztrb_db = result.get("E_ZTRB_DB", [])

            # Append the data to the combined_data list
            combined_data.extend(e_ztrb_db)

        # Emit the combined data when done
        self.result_ready.emit(combined_data)

    except Exception as e:
        # Emit an error message if an exception occurs
        self.error_occurred.emit(str(e))
