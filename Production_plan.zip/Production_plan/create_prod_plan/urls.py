from django.urls import path
from .views import create_plan_view

app_name = 'create_prod_plan'

urlpatterns = [
    path('create/', create_plan_view, name='create_plan'),
]
