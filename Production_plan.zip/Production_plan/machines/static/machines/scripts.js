document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('machineForm');
    const successMessage = document.getElementById('successMessage');
    const machinesTableBody = document.getElementById('machinesTableBody');
    const API_URL = '/machines/api/machines/'; // Django API endpoint

    // Kezdeti gép lista betöltése
    fetchMachines();

    // Űrlap beküldése
    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        // Form adatok beolvasása
        const name = document.getElementById('name').value.trim();
        const sapNumber = document.getElementById('sap_number').value.trim();
        const description = document.getElementById('description').value.trim();

        if (!name || !sapNumber || !description) {
            alert("All fields are required. Please fill out the form completely.");
            return;
        }

        // Új gép hozzáadása a szerverhez
        const newMachine = { name, sap_number: sapNumber, description };
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newMachine),
            });

            if (response.ok) {
                const addedMachine = await response.json();
                // Táblázat frissítése
                addMachineToTable(addedMachine);

                // Sikerüzenet
                successMessage.classList.remove('hidden');
                form.reset();

                // Üzenet elrejtése pár másodperc után
                setTimeout(() => {
                    successMessage.classList.add('hidden');
                }, 3000);
            } else {
                const errorData = await response.json();
                alert(`Error: ${JSON.stringify(errorData)}`);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Something went wrong. Please try again later.');
        }
    });

    // Gépek lekérdezése a szervertől
    async function fetchMachines() {
        try {
            const response = await fetch(API_URL);
            if (response.ok) {
                const machines = await response.json();
                machines.forEach(addMachineToTable);
            } else {
                console.error('Failed to fetch machines');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    // Gépek hozzáadása a táblázathoz
    function addMachineToTable(machine) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${machine.name}</td>
            <td>${machine.sap_number}</td>
            <td>${machine.description}</td>
        `;
        machinesTableBody.appendChild(row);
    }
});
