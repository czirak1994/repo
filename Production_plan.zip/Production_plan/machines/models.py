from django.db import models

class Machine(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name="Machine Name")
    sap_number = models.CharField(max_length=50, unique=True, verbose_name="SAP Number")
    description = models.TextField(null=True, blank=True, verbose_name="Description")
    utilization = models.FloatField(default=0.0, verbose_name="Utilization (%)")

    def __str__(self):
        return f"{self.name} ({self.sap_number})"
