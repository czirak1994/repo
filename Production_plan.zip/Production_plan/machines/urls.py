# machines/urls.py
from django.urls import path
from .views import MachineAPIView, add_machine_view

urlpatterns = [
    path('api/machines/', MachineAPIView.as_view(), name='machine-api'),
    path('add/', add_machine_view, name='add-machine'),
]

