# users/backends.py
from django.contrib.auth.backends import BaseBackend
from sap_functions.services import SAPConnectionManager
from .models import CustomUser

class SAPAuthBackend(BaseBackend):
    def authenticate(self, request, username=None, password=None):
        try:
            # SAP hitelesítés
            SAPConnectionManager.initialize_connection(user=username, password=password)

            # Felhasználó létrehozása vagy lekérdezése
            user, created = CustomUser.objects.get_or_create(username=username)

            # Alapértelmezett szerepkör
            if created:
                user.role = 'shift_leader'
                user.save()

            return user

        except Exception as e:
            print(f"Authentication failed: {e}")
            return None

    def get_user(self, user_id):
        try:
            return CustomUser.objects.get(pk=user_id)
        except CustomUser.DoesNotExist:
            return None
