from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.models import User
from ldap3 import Server, Connection, ALL

class LDAPBackend(BaseBackend):
    def authenticate(self, request, username=None, password=None):
        server = Server('ldap://krbtgt/BAD.BENTELER.NET @ BAD.BENTELER.NET', get_info=ALL)
        conn = Connection(server, user=f'{username}@yourdomain.com', password=password, auto_bind=True)

        if conn.bind():
            # Felhasználó automatikus létrehozása Django-ban
            user, created = User.objects.get_or_create(username=username)
            if created:
                user.set_password(password)  # Nem valódi jelszókezelés, csak demonstráció
                user.save()
            return user
        return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
