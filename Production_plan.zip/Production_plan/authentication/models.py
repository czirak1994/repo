from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models

class SAPUserManager(BaseUserManager):
    def create_user(self, username, sap_client, role, **extra_fields):
        if not username or not sap_client or not role:
            raise ValueError('Username, SAP client, and role are required')
        user = self.model(username=username, sap_client=sap_client, role=role, **extra_fields)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, username, sap_client, **extra_fields):
        extra_fields.setdefault('role', 'Admin')
        extra_fields.setdefault('is_admin', True)
        return self.create_user(username, sap_client, **extra_fields)
    
class SAPUser(AbstractBaseUser):
    ROLE_CHOICES = [
        ('Admin', 'Admin'),
        ('Production planner', 'Production planner'),
        ('User', 'User'),
    ]

    username = models.CharField(max_length=100, unique=True)
    sap_client = models.CharField(max_length=10)  # SAP kliens azonosító
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='User')  # Felhasználói szerepkör
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)

    objects = SAPUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['sap_client', 'role']

    def __str__(self):
        return f"{self.username} ({self.role})"

    @property
    def is_staff(self):
        return self.is_admin    