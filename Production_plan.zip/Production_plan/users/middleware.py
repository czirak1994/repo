from django.utils.cache import patch_cache_control
from django.utils.deprecation import MiddlewareMixin

class NoCacheMiddleware(MiddlewareMixin):
    """
    Middleware a gyorsítótár tiltására.
    """
    def process_response(self, request, response):
        patch_cache_control(response, no_cache=True, no_store=True, must_revalidate=True)
        return response
