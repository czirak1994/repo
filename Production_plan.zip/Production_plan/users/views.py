from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from sap_functions.services import SAPConnectionManager
from .models import CustomUser
from django.utils.cache import patch_cache_control

def login_view(request):
    """
    Bejelentkezési nézet.
    Az SAP hitelesítés sikeressége után a Django sessionbe helyezi a felhasználót.
    """
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        try:
            # SAP kapcsolat inicializálása és ping teszt
            SAPConnectionManager.initialize_connection(user=username, password=password)

            # Django hitelesítés
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)  # Django session beállítása
                next_url = request.GET.get('next', 'production:home')  # Átirányítás a megcélzott oldalra
                return redirect(next_url)
            else:
                return render(request, 'users/login.html', {'error': 'Authentication failed. Please try again.'})

        except Exception as e:
            # Hiba esetén hibaüzenet küldése a sablonba
            return render(request, 'users/login.html', {'error': f"Login failed: {str(e)}"})

    return render(request, 'users/login.html')

def user_logout(request):
    """
    Kijelentkezési nézet:
    - Session törlése.
    - Cache érvénytelenítése.
    - Átirányítás a bejelentkezési oldalra.
    """
    # Felhasználó kijelentkeztetése
    logout(request)

    # Session törlése
    request.session.flush()

    # Cache érvénytelenítése (ha szükséges)
    response = redirect('users:login')  # Átirányítás a login oldalra
    patch_cache_control(response, no_cache=True, no_store=True, must_revalidate=True)

    return response