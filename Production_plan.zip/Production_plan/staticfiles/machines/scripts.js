document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('machineForm');
    const successMessage = document.getElementById('successMessage');

    form.addEventListener('submit', async (event) => {
        event.preventDefault(); // Prevent form submission reload

        const formData = {
            name: document.getElementById('name').value,
            sap_number: document.getElementById('sap_number').value,
            description: document.getElementById('description').value,
        };

        try {
            const response = await fetch('/api/machines/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                successMessage.classList.remove('hidden');
                successMessage.textContent = 'Machine added successfully!';
                form.reset();
            } else {
                const errorData = await response.json();
                alert(`Error: ${JSON.stringify(errorData)}`);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Something went wrong!');
        }
    });
});
