// CSRF token lekérdezése
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Kijelentkezés kezelése
function logout() {
    fetch('/tasks/logout/', {
        method: "POST",
        headers: {
            "X-CSRFToken": getCookie('csrftoken'),
        },
        body: new URLSearchParams({
            csrfmiddlewaretoken: getCookie('csrftoken')
        })
    }).then(response => {
        if (response.ok) {
            window.location.href = "/"; // Kijelentkezés után átirányítás a kezdőlapra
        }
    }).catch(error => {
        console.error('Error:', error);
    });
}

// TaskTitles betöltése és csoportosítása
function loadTaskTitles() {
    fetch('/tasks/api/tasktitles/')
        .then(response => response.json())
        .then(data => {
            const taskList = document.getElementById('task-list');
            const groups = {};
            data.forEach(taskTitle => {
                const groupName = taskTitle.task_group_name || 'Névtelen csoport';
                if (!groups[groupName]) {
                    groups[groupName] = [];
                }
                groups[groupName].push(taskTitle);
            });
            for (const [groupName, tasks] of Object.entries(groups)) {
                const groupButton = document.createElement('button');
                groupButton.className = 'collapsible';
                groupButton.textContent = groupName;
                taskList.appendChild(groupButton);

                const groupContent = document.createElement('div');
                groupContent.className = 'content';
                tasks.forEach(taskTitle => {
                    const button = document.createElement('button');
                    button.className = 'task-button';
                    button.dataset.taskTitle = taskTitle.title;
                    button.textContent = taskTitle.title;
                    button.addEventListener('click', function() {
                        this.classList.toggle('selected');
                        updateSelectedTasks(this);
                    });
                    groupContent.appendChild(button);
                });
                taskList.appendChild(groupContent);
                groupButton.addEventListener('click', function() {
                    this.classList.toggle("active");
                    var content = this.nextElementSibling;
                    content.style.display = content.style.display === "block" ? "none" : "block";
                });
            }
        })
        .catch(error => console.error('Error fetching task titles:', error));
}

// Kiválasztott feladatok dinamikus frissítése a megerősítő ablakban
function updateSelectedTasks(taskButton) {
    const selectedTasksList = document.getElementById('selected-tasks-list');

    if (taskButton.classList.contains('selected')) {
        // Ha kiválasztott feladat, hozzáadjuk a megerősítő listához
        const taskItem = document.createElement('div');
        taskItem.classList.add('selected-task-item');
        taskItem.textContent = taskButton.dataset.taskTitle;
        taskItem.dataset.taskTitle = taskButton.dataset.taskTitle;

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Eltávolítás';
        removeButton.classList.add('remove-button');
        removeButton.addEventListener('click', function() {
            taskItem.remove();
            taskButton.classList.remove('selected');
        });

        taskItem.appendChild(removeButton);
        selectedTasksList.appendChild(taskItem);
    } else {
        // Ha már nem kiválasztott, eltávolítjuk a megerősítő listából
        const existingTaskItem = Array.from(selectedTasksList.children).find(
            item => item.dataset.taskTitle === taskButton.dataset.taskTitle
        );
        if (existingTaskItem) {
            existingTaskItem.remove();
        }
    }

    // Megjelenítjük a megerősítő ablakot, ha van kiválasztott feladat
    document.getElementById('confirmation-dialog').style.display = selectedTasksList.children.length > 0 ? 'block' : 'none';
}

// Feladatok küldése a megerősítés után
document.getElementById('confirm-send').addEventListener('click', function() {
    const selectedTasks = document.querySelectorAll('#selected-tasks-list .selected-task-item');
    const csrftoken = getCookie('csrftoken');
    const username = "{{ user.username }}";

    const promises = Array.from(selectedTasks).map(taskItem => {
        return fetch('/tasks/api/tasks/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken
            },
            body: JSON.stringify({
                title: taskItem.dataset.taskTitle,
                description: "1",
                created_by: username
            })
        }).then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        });
    });

    Promise.all(promises)
        .then(results => {
            console.log('Feladatok sikeresen elküldve:', results);
            document.getElementById('confirmation-dialog').style.display = 'none';
        })
        .catch(e => {
            console.error('Hiba a feladatok elküldésekor:', e.message);
        });
});

// Küldés visszavonása
document.getElementById('cancel-send').addEventListener('click', function() {
    document.getElementById('confirmation-dialog').style.display = 'none';
    const selectedTasksList = document.getElementById('selected-tasks-list');
    selectedTasksList.innerHTML = '';
    document.querySelectorAll('.task-button.selected').forEach(button => button.classList.remove('selected'));
});

// Feladatok betöltése az oldal betöltésekor
document.addEventListener('DOMContentLoaded', loadTaskTitles);
