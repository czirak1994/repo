//receiver.js
// CSRF token lekérdezése
function getCookie(name) {
    let value = `; ${document.cookie}`;
    let parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

// Kijelentkezés kezelése
function logout() {
    fetch('/tasks/logout/', {  // Az útvonalat abszolút URL-ként add meg
        method: "POST",
        headers: {
            "X-CSRFToken": getCookie('csrftoken'),
        },
        body: new URLSearchParams({
            csrfmiddlewaretoken: getCookie('csrftoken')
        })
    }).then(response => {
        if (response.ok) {
            window.location.href = "/";  // Kijelentkezés után átirányítás a kezdőlapra
        }
    }).catch(error => {
        console.error('Error:', error);
    });
}


const taskListDiv = document.getElementById('task-list');
const warehouseTaskListDiv = document.getElementById('warehouse-task-list');
const completeButton = document.getElementById('complete-button');

// WebSocket kapcsolat kezelése
function initializeSocketConnection(socketUrl, messageHandler) {
    const socket = new WebSocket(socketUrl);
    socket.onmessage = messageHandler;
    socket.onclose = () => console.log(`WebSocket kapcsolat bezárva: ${socketUrl}`);
    return socket;
}

// Általános feladatok WebSocket üzenetkezelője
function handleTasksSocketMessage(e) {
    const data = JSON.parse(e.data);
    if (data.type === 'task_created') {
        addTask(data.task, taskListDiv);
        playNotificationSound();
        showVisualNotification("Új feladat érkezett", data.task.title);
    } else if (data.type === 'task_selected') {
        disableTask(data.task_id, data.username);  // Itt biztosítjuk, hogy a kiválasztó felhasználó neve is átadásra kerüljön
    } else if (data.type === 'task_deselected') {
        enableTask(data.task_id);
    } else if (data.type === 'task_completed') {
        removeTask(data.task_id);
    }
}

function handleWarehouseSocketMessage(e) {
    const data = JSON.parse(e.data);
    if (data.type === 'warehouse_task_created') {
        addTask(data.task, warehouseTaskListDiv);
        playNotificationSound();
        showVisualNotification("Új raktári feladat érkezett", data.task.title);
    } else if (data.type === 'warehouse_task_completed') {
        removeTask(data.task_id);  // Automatikusan eltávolítja a teljesített warehouse feladatokat
    }
}


const tasksSocket = initializeSocketConnection('wss://' + window.location.host + '/wss/tasks/', handleTasksSocketMessage);
const warehouseTasksSocket = initializeSocketConnection('wss://' + window.location.host + '/wss/warehouse_tasks/', handleWarehouseSocketMessage);

// Értesítési hang lejátszása
function playNotificationSound() {
    const notificationSound = document.getElementById("notification-sound");
    notificationSound.play().catch(error => {
        console.error("A hang nem játszható le automatikusan:", error);
    });
}

// Vizuális értesítés megjelenítése
function showVisualNotification(title, message) {
    const notificationPopup = document.getElementById("notification-popup");
    notificationPopup.textContent = title + ": " + message;
    notificationPopup.style.display = "block";

    setTimeout(() => {
        notificationPopup.style.display = "none";
    }, 5000);
}

// Feladat hozzáadása
function addTask(task, listDiv) {
    if (!task.completed) {
        const taskDiv = document.createElement('div');
        taskDiv.classList.add('task');
        taskDiv.textContent = task.title;
        taskDiv.dataset.taskId = task.id;
        taskDiv.onclick = task.is_selected
            ? () => deselectTask(task.id, taskDiv)
            : () => selectTask(task.id, taskDiv);
        listDiv.appendChild(taskDiv);
    }
}

/// Feladat kiválasztása
function selectTask(taskId, taskDiv) {
    fetch('/tasks/api/select-task/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({
            'task_id': taskId,
            'username': username,
            'action': 'select'
        })
    }).then(response => {
        if (response.ok) {
            taskDiv.classList.add('selected');
            taskDiv.onclick = () => deselectTask(taskId, taskDiv);
            disableTask(taskId, username);  // Ezt a funkciót az alábbiakban adjuk meg
        } else {
            console.error('Task already selected');
        }
    }).catch(error => console.error('Error selecting task:', error));
}

// Feladat letiltása más felhasználók számára
function disableTask(taskId, selectedByUsername) {
    const taskDiv = document.querySelector(`.task[data-task-id='${taskId}']`);
    if (taskDiv) {
        // Ha a feladatot más felhasználó választotta ki, akkor valóban letiltjuk
        if (selectedByUsername !== username) {
            taskDiv.classList.add('disabled'); // CSS osztály, hogy vizuálisan jelezze a tiltást
            taskDiv.onclick = null; // Kattintás letiltása más felhasználók számára
            taskDiv.title = `Feladat kiválasztva: ${selectedByUsername}`; // Tooltip az információ megjelenítéséhez
        } else {
            // Ha mi magunk választottuk ki a feladatot, állítsuk be a "deselect" eseményt
            taskDiv.classList.add('selected'); // Kijelölt stílus hozzáadása
            taskDiv.onclick = () => deselectTask(taskId, taskDiv); // Lehetővé tesszük a kijelölés feloldását
            taskDiv.title = "Kattintson a kijelölés feloldásához";
        }

        // Opcionális: kijelölő felhasználó információja
        let selectedUserInfo = taskDiv.querySelector('.selected-user-info');
        if (!selectedUserInfo) {
            selectedUserInfo = document.createElement('span');
            selectedUserInfo.classList.add('selected-user-info');
            taskDiv.appendChild(selectedUserInfo);
        }
        selectedUserInfo.textContent = `Kiválasztotta: ${selectedByUsername}`;
    }
}

// Feladat engedélyezése (deselection esetén)
function enableTask(taskId) {
    const taskDiv = document.querySelector(`.task[data-task-id='${taskId}']`);
    if (taskDiv) {
        taskDiv.classList.remove('disabled', 'selected'); // Eltávolítjuk a tiltott és kijelölt osztályokat
        taskDiv.onclick = () => selectTask(taskId, taskDiv); // Újra lehetővé tesszük a kijelölést
        taskDiv.title = ""; // Tooltip törlése

        // Kiválasztotta információ eltávolítása
        const selectedUserInfo = taskDiv.querySelector('.selected-user-info');
        if (selectedUserInfo) {
            selectedUserInfo.remove();
        }
    }
}




// Feladat feloldása
function deselectTask(taskId, taskDiv) {
    fetch('/tasks/api/select-task/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({
            'task_id': taskId,
            'username': username,
            'action': 'deselect'
        })
    }).then(response => {
        if (response.ok) {
            taskDiv.classList.remove('selected');
            taskDiv.onclick = () => selectTask(taskId, taskDiv);
            enableTask(taskId); // Feladat újra elérhetővé tétele
        } else {
            console.error('Error deselecting task');
        }
    }).catch(error => console.error('Error deselecting task:', error));
}



// Feladat eltávolítása
function removeTask(taskId) {
    const taskDiv = document.querySelector(`.task[data-task-id='${taskId}']`);
    if (taskDiv) {
        taskDiv.remove();
    } else {
        console.warn(`Nem található a feladat a következő ID-val: ${taskId}`);
    }
}
// Feladat teljesítése
completeButton.addEventListener('click', function() {
    const selectedTasks = [];
    document.querySelectorAll('.task.selected').forEach(taskDiv => {
        selectedTasks.push(taskDiv.dataset.taskId);
    });

    if (selectedTasks.length > 0) {
        fetch('/tasks/api/complete-tasks/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({ task_ids: selectedTasks, completed_by: username })
        })
        .then(response => response.ok ? response.json() : response.json().then(data => { throw new Error(data.message); }))
        .then(data => {
            if (data.status === 'success') {
                selectedTasks.forEach(taskId => removeTask(taskId));
            } else {
                console.error('Failed to complete tasks:', data.message);
            }
        })
        .catch(error => console.error('Failed to complete tasks:', error));
    } else {
        console.log('No tasks selected.');
    }
});

// Feladatok betöltése oldalfrissítéskor
function loadTasks() {
    fetch('/tasks/api/get-tasks/', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
    .then(response => response.json())
    .then(data => {
        // Minden feladatot feldolgozunk
        data.tasks.forEach(task => {
            if (task.is_selected) {
                // Ha a feladat ki van választva, tiltás és kijelző üzenet, hogy ki dolgozik rajta
                disableTask(task.id, task.selected_by);
            } else if (!task.completed) {
                // Ha a feladat nincs kiválasztva és még nincs teljesítve
                addTask(task, taskListDiv);
            }
        });
    })
    .catch(error => console.error('Hiba a feladatok betöltésekor:', error));
}

// Meghívás az oldal betöltésekor
document.addEventListener('DOMContentLoaded', loadTasks);
