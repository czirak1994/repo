#models.py
from django.db import models
from django.contrib.auth.models import User

      
class TaskGroup(models.Model):
    name = models.CharField(max_length=100, unique=True)  # Egyedi név a TaskGroup számára

    def __str__(self):
        return self.name
class TaskTitle(models.Model):
    title = models.CharField(max_length=200)
    task_group = models.ForeignKey(TaskGroup, on_delete=models.CASCADE, related_name='task_titles')

    def __str__(self):
        return self.title

class AbstractTask(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.CharField(max_length=200)
    completed = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    completed_by = models.CharField(max_length=200, null=True, blank=True)
    is_selected = models.BooleanField(default=False)
    selected_by = models.CharField(max_length=200, null=True, blank=True)
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        abstract = True  # Ezzel az osztályt absztrakttá tesszük, így nem hoz létre külön táblát

    def __str__(self):
        return self.title

class Task(AbstractTask):
    # Speciális mezők adhatók hozzá, ha szükséges
    pass

class WarehouseTask(AbstractTask):
    # Speciális mezők adhatók hozzá, ha szükséges
    pass        