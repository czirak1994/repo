from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            if user.groups.filter(name='keszletezo').exists():
                return redirect('tasks')
            elif user.groups.filter(name='raktaros').exists():
                return redirect('receiver')
            elif user.groups.filter(name='shift_leader').exists():
                return redirect('shift_leader')
            return redirect('home')
    return render(request, 'login.html', {'form': {'errors': True}})

def logout_view(request):
    logout(request)
    return redirect('login')
