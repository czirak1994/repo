# views/utils.py

from django.contrib.sessions.models import Session
from django.contrib.auth.models import User
from django.utils import timezone
from django.http import JsonResponse

def get_logged_in_users():
    active_sessions = Session.objects.filter(expire_date__gte=timezone.now())
    user_ids = [session.get_decoded().get('_auth_user_id') for session in active_sessions]
    users = User.objects.filter(id__in=user_ids)
    return JsonResponse([{"id": user.id, "username": user.username} for user in users], safe=False)
