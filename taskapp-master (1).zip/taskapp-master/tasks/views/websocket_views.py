from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from tasks.models import Task, WarehouseTask
import json
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

@csrf_exempt
def complete_tasks(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        task_ids = data.get('task_ids', [])
        tasks = Task.objects.filter(id__in=task_ids, completed=False, selected_by=request.user.username)
        tasks.update(completed=True, completed_by=request.user.username)
        channel_layer = get_channel_layer()
        for task_id in task_ids:
            async_to_sync(channel_layer.group_send)(
                'tasks', {'type': 'task_completed', 'task_id': task_id, 'completed_by': request.user.username}
            )
        return JsonResponse({'status': 'success'})
    return HttpResponseBadRequest('Invalid request')

@csrf_exempt
def select_task(request):
    if request.method == "POST":
        data = json.loads(request.body)
        task_id = int(data.get("task_id"))
        username = data.get("username")
        action = data.get("action")
        task = (WarehouseTask if data.get("task_type") == "warehouse" else Task).objects.get(id=task_id)
        
        if action == "select":
            task.is_selected, task.selected_by = True, username
        elif action == "deselect" and task.selected_by == username:
            task.is_selected, task.selected_by = False, None
        task.save()
        
        # WebSocket Notification
        async_to_sync(get_channel_layer().group_send)(
            "tasks", {"type": "task_selected_event" if action == "select" else "task_deselected_event", "task_id": task_id, "username": username}
        )
        return JsonResponse({"status": "success"})
    return HttpResponseBadRequest("Invalid request method")
