import json
from django.shortcuts import redirect, render
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import user_passes_test
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from tasks.models import Task

@user_passes_test(lambda u: u.groups.filter(name='shift_leader').exists())
def shift_leader_view(request):
    return render(request, 'shift_leader.html')

@csrf_exempt
def create_warehouse_task(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        title = data.get('title')
        description = data.get('description')
        user_id = data.get('user_id')
        task = WarehouseTask.objects.create(
            title=title, description=description, created_by=request.user.username, assigned_to_id=user_id
        )
        async_to_sync(get_channel_layer().group_send)(
            f"user_{user_id}",
            {'type': 'warehouse_task_created', 'task': {'id': task.id, 'title': task.title, 'description': task.description}}
        )
        return JsonResponse({'status': 'success', 'task_id': task.id})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

@csrf_exempt
@user_passes_test(lambda u: u.is_staff or u.has_perm('app.shift_leader'))
def assign_task_to_user(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        user_id = data.get('user_id')
        title = data.get('title')
        description = data.get('description')

        try:
            user = User.objects.get(id=user_id)
            # Új feladat létrehozása
            task = Task.objects.create(
                title=title,
                description=description,
                created_by=request.user.username  # a bejelentkezett shift_leader felhasználó
            )
            
            # WebSocket értesítés az adott felhasználónak
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{user_id}",  # Egyedi csatorna az adott felhasználónak
                {
                    "type": "warehouse_task_created",
                    "task": {
                        "id": task.id,
                        "title": task.title,
                        "description": task.description,
                        "created_by": task.created_by
                    }
                }
            )

            return JsonResponse({'status': 'success', 'task_id': task.id})
        except User.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'User not found'}, status=404)

    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)
