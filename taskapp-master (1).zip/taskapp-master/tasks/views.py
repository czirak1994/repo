#views.py
from django.shortcuts import render, redirect
from rest_framework import viewsets
from .models import Task, WarehouseTask, TaskGroup, TaskTitle
from .serializers import TaskSerializer, TaskTitleSerializer, TaskGroupSerializer
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.http import HttpResponse, JsonResponse, HttpResponseBadRequest
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
from django.contrib.sessions.models import Session
from django.contrib.auth.models import User
from django.utils import timezone
from django.contrib.auth.decorators import user_passes_test

class TaskTitleViewSet(viewsets.ModelViewSet):
    queryset = TaskTitle.objects.all()
    serializer_class = TaskTitleSerializer
    
class TaskGroupViewSet(viewsets.ModelViewSet):
    queryset = TaskGroup.objects.all()
    serializer_class = TaskGroupSerializer    

def home(request):
    if not request.user.is_authenticated:
        return redirect('login')
    return HttpResponse("Benteler Task Manager")

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Átirányítás csoport alapján
            if user.groups.filter(name='keszletezo').exists():
                return redirect('tasks')
            elif user.groups.filter(name='raktaros').exists():
                return redirect('receiver')
            elif user.groups.filter(name='shift_leader').exists():
                return redirect('shift_leader')
            else:
                return redirect('home')
        else:
            return render(request, 'login.html', {'form': {'errors': True}})
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')


class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

    def perform_create(self, serializer):
        try: 
            task = serializer.save()
        except Exception as e:
            print(f"Task creation error: {e}")     
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
        # Send a message over the WebSocket connection
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            'tasks',  # This should match the group name in your consumer
            {
                'type': 'task.created',
                'task': {
                    'id': task.id,
                    'title': task.title,
                    'description': task.description,
                    # ... any other task fields you want to include ...
                },
            }
        )


@login_required
def list_tasks(request):
    task_groups = {}
    for task_title in TaskTitle.objects.all():
        group_name = task_title.task_group.name
        if group_name not in task_groups:
            task_groups[group_name] = []
        task_groups[group_name].append(task_title)

    context = {'task_groups': task_groups}
    return render(request, 'tasks.html', context)

def create_task(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        # Hozzáadjuk a bejelentkezett felhasználó nevét a created_by mezőhöz
        Task.objects.create(
            title=title,
            description=description,
            created_by=request.user.username  # A bejelentkezett felhasználó neve kerül a created_by mezőbe
        )
        return redirect('list-tasks')  # Térjen vissza a feladatok listájához

@csrf_exempt
def send_tasks(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            for task_data in data:
                task_data['created_by'] = request.user.username  # Bejelentkezett felhasználó hozzáadása
                serializer = TaskSerializer(data=task_data)
                if serializer.is_valid():
                    serializer.save()
                else:
                    return JsonResponse({'status': 'error', 'errors': serializer.errors}, status=400)
            return JsonResponse({'status': 'success'}, status=201)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON format'}, status=400)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    

@login_required
def receiver_view(request):
    return render(request, 'receiver.html', {'user': request.user})



@csrf_exempt
def complete_tasks(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            task_ids = data.get('task_ids', [])
            if not task_ids:
                return JsonResponse({'status': 'error', 'message': 'No task IDs provided'}, status=400)

            tasks = Task.objects.filter(id__in=task_ids, completed=False, selected_by=request.user.username)
            tasks.update(completed=True, completed_by=request.user.username)

            # Értesítés a WebSocket csoportnak
            channel_layer = get_channel_layer()
            for task_id in task_ids:
                async_to_sync(channel_layer.group_send)(
                    'tasks', {
                        'type': 'task_completed',
                        'task_id': task_id,
                        'completed_by': request.user.username
                    }
                )
            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

@csrf_exempt
def select_task(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            task_id = int(data.get("task_id"))
            username = data.get("username")
            action = data.get("action")
            task_type = data.get("task_type", "task")

            TaskModel = WarehouseTask if task_type == "warehouse" else Task
            task = TaskModel.objects.get(id=task_id)

            if action == "select":
                if task.is_selected and task.selected_by != username:
                    return JsonResponse({"status": "error", "message": "Task already selected by another user"})
                
                task.is_selected = True
                task.selected_by = username
                task.save()

                # WebSocket üzenet küldése a feladat kiválasztásáról
                channel_layer = get_channel_layer()
                async_to_sync(channel_layer.group_send)(
                    "tasks",
                    {
                        "type": "task_selected_event",
                        "task_id": task_id,
                        "username": username
                    }
                )

                return JsonResponse({"status": "success"})

            elif action == "deselect":
                if task.is_selected and task.selected_by == username:
                    task.is_selected = False
                    task.selected_by = None
                    task.save()

                    # WebSocket üzenet küldése a feladat feloldásáról
                    channel_layer = get_channel_layer()
                    async_to_sync(channel_layer.group_send)(
                        "tasks",
                        {
                            "type": "task_deselected_event",
                            "task_id": task_id
                        }
                    )

                    return JsonResponse({"status": "success"})
                
                return JsonResponse({"status": "error", "message": "Cannot deselect task not selected by user"})

            return HttpResponseBadRequest("Invalid action")

        except (WarehouseTask.DoesNotExist, Task.DoesNotExist, ValueError):
            return HttpResponseBadRequest("Invalid task ID or data format")
    else:
        return HttpResponseBadRequest("Invalid request method")




def get_logged_in_users(request):
    active_sessions = Session.objects.filter(expire_date__gte=timezone.now())
    user_ids = [session.get_decoded().get('_auth_user_id') for session in active_sessions]
    users = User.objects.filter(id__in=user_ids)
    user_data = [{"id": user.id, "username": user.username} for user in users]
    return JsonResponse(user_data, safe=False)

# API az összes feladat betöltéséhez az aktuális állapottal együtt
@csrf_exempt
def get_tasks(request):
    tasks = Task.objects.all()
    tasks_data = [
        {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "is_selected": task.is_selected,
            "selected_by": task.selected_by,
            "completed": task.completed,
            "created_by": task.created_by
        }
        for task in tasks
    ]
    return JsonResponse({"tasks": tasks_data}, safe=False)


def assign_task_to_user(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        user_id = data.get('user_id')
        title = data.get('title')
        description = data.get('description')

        try:
            user = User.objects.get(id=user_id)
            # Új feladat létrehozása
            task = Task.objects.create(
                title=title,
                description=description,
                created_by=request.user.username  # a bejelentkezett shift_leader felhasználó
            )
            
            # WebSocket értesítés az adott felhasználónak
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{user_id}",  # Egyedi csatorna az adott felhasználónak
                {
                    "type": "warehouse_task_created",
                    "task": {
                        "id": task.id,
                        "title": task.title,
                        "description": task.description,
                        "created_by": task.created_by
                    }
                }
            )

            return JsonResponse({'status': 'success', 'task_id': task.id})
        except User.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'User not found'}, status=404)

    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

@user_passes_test(lambda u: u.is_staff or u.has_perm('app.shift_leader'))
def shift_leader_view(request):
    return render(request, 'shift_leader.html')

def warehouse_tasks_view(request):
    try:
        # Lekérjük a "Raktár" nevű TaskGroup-ot
        warehouse_group = TaskGroup.objects.get(name="Raktár")
        
        # Szűrjük a Task objektumokat a TaskTitle és TaskGroup kapcsolaton keresztül
        warehouse_task_titles = TaskTitle.objects.filter(task_group=warehouse_group)
        warehouse_tasks = Task.objects.filter(title__in=warehouse_task_titles.values_list('title', flat=True))

        # JSON válasz létrehozása
        tasks_data = [
            {
                "id": task.id,
                "title": task.title,
                "description": task.description,
                "created_by": task.created_by,
                "created_at": task.created_at,
                "completed": task.completed,
                "completed_by": task.completed_by,
                "updated_at": task.updated_at,
                "is_selected": task.is_selected,
                "selected_by": task.selected_by
            }
            for task in warehouse_tasks
        ]
        return JsonResponse(tasks_data, safe=False)

    except TaskGroup.DoesNotExist:
        return JsonResponse({"error": "Raktár csoport nem található."}, status=404)
    
@user_passes_test(lambda u: u.groups.filter(name='shift_leader').exists())  # Csak shift_leader csoport
@csrf_exempt
def create_warehouse_task(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
            title = data.get('title')
            description = data.get('description')
            user_id = data.get('user_id')  # Címzett felhasználó ID-ja

            assigned_user = User.objects.get(id=user_id)
            task = WarehouseTask.objects.create(
                title=title,
                description=description,
                created_by=request.user.username,
                assigned_to=assigned_user
            )

            # Küldés a WebSocket-en keresztül a címzett felhasználónak
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{assigned_user.id}",
                {
                    'type': 'warehouse_task_created',  # pontos csoportnév és típus
                    'task': {
                        'id': task.id,
                        'title': task.title,
                        'description': task.description,
                    },
                }
            )
            return JsonResponse({'status': 'success', 'task_id': task.id})

        except User.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'User not found'}, status=404)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)